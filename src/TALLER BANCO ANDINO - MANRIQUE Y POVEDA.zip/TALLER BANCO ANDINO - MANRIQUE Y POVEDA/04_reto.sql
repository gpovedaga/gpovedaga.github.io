-- =====================================================================
-- Bases de Datos 2 · Taller integrador — Banco Andino
-- 04_reto.sql   Reto final (25 minutos)
--
-- Trabajen en UNA SOLA CONEXIÓN: la pareja comparte el esquema.
-- Este es el ejercicio que se entrega.
-- Todo se resuelve con SQL. No se necesita PL/SQL.
-- =====================================================================

-- ---------------------------------------------------------------------
-- EL TICKET
--
--   De:    Gerencia de Operaciones, Banco Andino
--   Para:  Equipo de Base de Datos
--   Asunto: CRÍTICO — descuadres en transferencias
--
--   "Desde el puente festivo tenemos tres problemas:
--
--    1. La cuenta de compensación no cuadra. Hay días en que el total
--       debitado no coincide con el total acreditado, por montos
--       pequeños pero constantes. Contraloría ya abrió un caso.
--
--    2. Aparecieron transferencias donde al cliente le descontaron la
--       plata y nunca le llegó al destinatario. Otras al revés: llegó
--       al destino sin haber salido del origen. Nadie sabe cuántas son.
--
--    3. El tablero de la Vicepresidencia se demora casi un minuto en
--       abrir, y lo consultan cada media hora.
--
--    Adjunto la secuencia de sentencias que ejecuta el core cada vez
--    que se aplica una transferencia, y la consulta del tablero.
--    Necesitamos un diagnóstico y la corrección."
-- ---------------------------------------------------------------------


-- #####################################################################
-- PIEZA 1 — Lo que ejecuta el core al aplicar una transferencia
--
-- Caso real: la transferencia 950001, de la cuenta 1001 a la 1002,
-- por 300.000 pesos.
--
-- Ejecútelo tal como está y observe qué hace. NO lo corrija todavía.
-- #####################################################################

-- Deje las cuentas en un valor conocido antes de probar
UPDATE cuenta SET saldo = 1000000, version = 0 WHERE id_cuenta IN (1001, 1002);
UPDATE transferencia SET estado = 'REGISTRADA' WHERE id_transferencia = 950001;
COMMIT;

SELECT id_cuenta, saldo FROM cuenta WHERE id_cuenta IN (1001,1002) ORDER BY id_cuenta;


--- inicio de lo que ejecuta el core -----------------------------------

-- 1. Débito del origen: la aplicación lee el saldo...
SELECT saldo FROM cuenta WHERE id_cuenta = 1001;
--> ...guarda ese número, le resta 300.000, y escribe el resultado:
UPDATE cuenta SET saldo = 700000 WHERE id_cuenta = 1001;
COMMIT;

-- 2. Crédito del destino: lo mismo al otro lado
SELECT saldo FROM cuenta WHERE id_cuenta = 1002;
--> ...le suma 300.000 y escribe:
UPDATE cuenta SET saldo = 1300000 WHERE id_cuenta = 1002;
COMMIT;

-- 3. Los dos movimientos contables
INSERT INTO movimiento (id_movimiento, id_cuenta, id_transferencia, fecha_mov, tipo, valor)
VALUES (9500001, 1001, 950001, SYSDATE, 'DEBITO', 300000);
COMMIT;

INSERT INTO movimiento (id_movimiento, id_cuenta, id_transferencia, fecha_mov, tipo, valor)
VALUES (9500002, 1002, 950001, SYSDATE, 'CREDITO', 300000);
COMMIT;

-- 4. Y al final marca la transferencia
UPDATE transferencia SET estado = 'APLICADA' WHERE id_transferencia = 950001;
COMMIT;

--- fin de lo que ejecuta el core --------------------------------------

SELECT id_cuenta, saldo FROM cuenta WHERE id_cuenta IN (1001,1002) ORDER BY id_cuenta;


-- #####################################################################
-- PIEZA 2 — La consulta del tablero de la Vicepresidencia
-- #####################################################################

SELECT s.ciudad,
       COUNT(DISTINCT t.id_transferencia)  AS operaciones,
       ROUND(SUM(t.valor))                 AS valor_total,
       ROUND(AVG(t.valor))                 AS ticket
  FROM transferencia t
  JOIN cuenta        c ON c.id_cuenta   = t.cuenta_origen
  JOIN sucursal      s ON s.id_sucursal = c.id_sucursal
 WHERE TO_CHAR(t.fecha_transf, 'YYYY-MM') = '2026-03'
   AND t.estado = 'APLICADA'
 GROUP BY s.ciudad
 ORDER BY valor_total DESC;


-- #####################################################################
-- LO QUE HAY QUE ENTREGAR
-- #####################################################################
--
-- A. DIAGNÓSTICO  (4 puntos)
--
--    Identifique CUATRO defectos en la secuencia de la PIEZA 1.
--    Para cada uno indique:
--      - qué sentencia o qué parte de la secuencia lo causa
--      - cuál de los tres síntomas del ticket produce
--      - qué pasa en producción con 12.000 transferencias por hora
--
--    Pista: uno es de concurrencia, uno es de transaccionalidad, uno
--    hace que el problema pase inadvertido, y uno es de rendimiento.
--
--    Dos de ellos hay que REPRODUCIRLOS, no solo describirlos:
--      - el de concurrencia: ejecuten la secuencia desde las DOS
--        conexiones sobre la misma cuenta y muestren el resultado


--DEFECTO DE CONCURRENCIA: LA APLICACIÓN LEE EL SALDO Y POSTERIORMENTE ESCRIBE UN VALOR CALCULADO CON ESA LECTURA
--SI DOS OPERACIONES SE EJECUTAN SIMULTÁNEAMENTE, UNA PUEDE SOBRESCRIBIR EL CAMBIO DE LA OTRA, PRODUCIENDO UNA ACTUALIZACIÓN PERDIDA. 
--EN LA PRUEBA, EL SALDO DEBIÓ QUEDAR EN $500.000, PERO QUEDÓ EN $800.000.

--      - el de transaccionalidad: simulen una falla después del débito
--        y antes del crédito, y muestren el estado en que quedan las
--        dos cuentas y la transferencia


--DEFECTO DE TRANSACCIONALIDAD: SE HACE COMMIT DESPUÉS DEL DÉBITO Y ANTES DEL CRÉDITO.
--SI OCURRE UNA FALLA ENTRE AMBAS OPERACIONES, EL DINERO SALE DEL ORIGEN PERO NO LLEGA AL DESTINO.
--EN LA PRUEBA, 1001 QUEDÓ EN $700.000, 1002 EN $1.000.000 Y LA TRANSFERENCIA 950001 PERMANECIÓ EN REGISTRADA.
--
--
-- B. CORRECCIÓN  (4 puntos)
--
--    Reescriba la secuencia usando SQL. Debe cumplir las cinco cosas:
--      1. que dos operaciones simultáneas sobre la misma cuenta no
--         puedan perder dinero
--      2. que sea atómica: el débito, el crédito, los dos movimientos y
--         el cambio de estado ocurren todos, o no ocurre ninguno
--      3. que se note cuando algo no se aplicó, en lugar de pasar en
--         silencio
--      4. que no permita dejar una cuenta en saldo negativo
--      5. que dos transferencias cruzadas simultáneas (1001->1002 y
--         1002->1001) NO puedan provocar un interbloqueo
--
--    El punto 5 es el que distingue este caso: no basta con bloquear,
--    hay que bloquear EN UN ORDEN DETERMINISTA.
--
--    Dispone de las herramientas que ya vieron hoy:
--      - SELECT ... FOR UPDATE con ORDER BY   (parte 1)
--      - UPDATE ... SET col = col +/- n
--      - un solo COMMIT al final, o ROLLBACK
--      - la restricción CHECK que ya tiene la tabla CUENTA
--
--    Demuéstrelo: ejecute su versión desde las DOS conexiones al mismo
--    tiempo, en sentidos cruzados, y muestre que no hay ORA-00060 y que
--    los saldos cuadran. Documente cómo lo probó.


--
-- C. OPTIMIZACIÓN DE LA CONSULTA  (1 punto)
--
--      - Capture el plan actual y anote COST y consistent gets
--      - Identifique qué impide el uso del índice
--      - Reescriba la consulta y/o cree el índice necesario
--      - Capture el plan nuevo y anote la mejora
--      - Justifique el índice: qué consulta lo usa y por qué no bastaba
--        con los que ya existen



--SE OPTIMIZÓ EL FILTRO DE FECHA REEMPLAZANDO TO_CHAR POR UN RANGO DE FECHAS Y SE
--PROBARON ÍNDICES ADICIONALES. ORACLE MANTUVO TABLE ACCESS FULL, PERO LOS 
--CONSISTENT GETS DISMINUYERON DE 2259 A 2248, POR LO QUE SE OBTUVO UNA MEJORA 
--PEQUEÑA EN EL RENDIMIENTO DE LA CONSULTA.
--
--
-- D. UNA RECOMENDACIÓN  (1 punto)
--
--    En un párrafo dirigido a la Gerencia de Operaciones: ¿qué práctica
--    debe cambiar el banco para que este problema no vuelva a aparecer?
--    No hable de esta consulta ni de estas sentencias: hable de la
--    organización. Considere que el descuadre existió durante semanas
--    antes de que alguien lo notara.

--SE RECOMIENDA AL BANCO IMPLEMENTAR CONTROLES AUTOMÁTICOS Y PERIÓDICOS DE 
--CONCILIACIÓN ENTRE LAS CUENTAS Y LOS MOVIMIENTOS REGISTRADOS, ACOMPAÑADOS DE 
--ALERTAS INMEDIATAS ANTE CUALQUIER DESCUADRE. ADEMÁS, SE DEBEN ESTABLECER 
--RESPONSABLES, AUDITORÍAS Y PROCEDIMIENTOS DE REVISIÓN PARA DETECTAR Y CORREGIR 
--LAS INCONSISTENCIAS DE FORMA OPORTUNA, EVITANDO QUE UN ERROR PUEDA PERMANECER 
--DURANTE SEMANAS SIN SER IDENTIFICADO.

--
--
-- FORMATO DE ENTREGA
--   Un archivo .sql con la secuencia corregida y la consulta optimizada,
--   más un documento corto con las respuestas a A y D y las capturas de
--   los planes de ejecución del punto C.
-- #####################################################################


-- ---------------------------------------------------------------------
-- Zona de trabajo: escriba aquí su versión corregida


-- ##############################
-- CORRECCIÓN: TRANSFERENCIA SEGURA Y ATÓMICA
-- ##############################

-- 1. BLOQUEAR LAS DOS CUENTAS EN UN ORDEN DETERMINISTA
SELECT id_cuenta, saldo
FROM cuenta
WHERE id_cuenta IN (1001, 1002)
ORDER BY id_cuenta
FOR UPDATE;


-- 2. DESCONTAR EL VALOR DE LA CUENTA ORIGEN
UPDATE cuenta
SET saldo = saldo - 300000,
    version = version + 1
WHERE id_cuenta = 1001
  AND saldo >= 300000;


-- 3. ACREDITAR EL VALOR EN LA CUENTA DESTINO
UPDATE cuenta
SET saldo = saldo + 300000,
    version = version + 1
WHERE id_cuenta = 1002;


-- 4. REGISTRAR EL MOVIMIENTO DE DÉBITO
INSERT INTO movimiento
(id_movimiento, id_transferencia, id_cuenta, tipo_movimiento, valor)
VALUES
(9500001, 950001, 1001, 'DEBITO', 300000);


-- 5. REGISTRAR EL MOVIMIENTO DE CRÉDITO
INSERT INTO movimiento
(id_movimiento, id_transferencia, id_cuenta, tipo_movimiento, valor)
VALUES
(9500002, 950001, 1002, 'CREDITO', 300000);


-- 6. CAMBIAR EL ESTADO DE LA TRANSFERENCIA
UPDATE transferencia
SET estado = 'APLICADA'
WHERE id_transferencia = 950001
  AND estado = 'REGISTRADA';


-- 7. VERIFICAR SALDOS Y ESTADO ANTES DE CONFIRMAR
SELECT id_cuenta, saldo
FROM cuenta
WHERE id_cuenta IN (1001, 1002)
ORDER BY id_cuenta;

SELECT id_transferencia, estado
FROM transferencia
WHERE id_transferencia = 950001;


-- 8. CONFIRMAR TODA LA OPERACIÓN
COMMIT;

-- EN CASO DE ERROR:
-- ROLLBACK;


-- ##############################
-- CONSULTA OPTIMIZADA
-- ##############################

SELECT s.ciudad,
       COUNT(DISTINCT t.id_transferencia) AS operaciones,
       ROUND(SUM(t.valor)) AS valor_total,
       ROUND(AVG(t.valor)) AS ticket
FROM transferencia t
JOIN cuenta c
  ON c.id_cuenta = t.cuenta_origen
JOIN sucursal s
  ON s.id_sucursal = c.id_sucursal
WHERE t.fecha_transf >= DATE '2026-03-01'
  AND t.fecha_transf < DATE '2026-04-01'
  AND t.estado = 'APLICADA'
GROUP BY s.ciudad
ORDER BY valor_total DESC;

-- ---------------------------------------------------------------------

-- Sugerencia de estructura, para que no se pierdan:
--
--   1. Bloquee las DOS cuentas en una sola sentencia, ordenadas por
--      id_cuenta. Ese ORDER BY es lo que elimina el interbloqueo.
--   2. Debite el origen y acredite el destino, siempre sobre el valor
--      actual de la fila, nunca sobre un número leído antes.
--   3. Inserte los dos movimientos.
--   4. Cambie el estado de la transferencia, condicionado al estado
--      esperado.
--   5. Revise cuántas filas afectó cada sentencia antes de confirmar.
--   6. Un solo COMMIT al final; si algo salió mal, ROLLBACK.