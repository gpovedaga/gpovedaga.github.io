-- =====================================================================
-- 03_template_entrega_taller1_v2.sql
-- Taller aplicado 1 - SQL avanzado + Transacciones (ACID) aplicado
-- Plantilla de entrega para estudiantes
--
-- IMPORTANTE:
-- 1. Trabajar únicamente sobre las tablas T1_% y AUDIT_SALARY_ADJUSTMENTS_T1
-- 2. NO modificar la estructura del entorno entregado por el docente
-- 3. NO eliminar secciones de esta plantilla
-- 4. Reemplazar únicamente los bloques indicados como "ESCRIBA AQUÍ"
-- 5. Usar la variante asignada por el docente (1, 2, 3 o 4)
-- 6. Usar un tag único de ejecución final, por ejemplo: P03_FINAL
-- =====================================================================

SET SERVEROUTPUT ON
SET FEEDBACK ON

-- ============================================================
-- 0. ENCABEZADO OBLIGATORIO
-- Complete toda esta información antes de ejecutar el script.
-- ============================================================
-- Integrante 1: NATALY MANRIQUE VERA
-- Integrante 2: DANIEL AGUDELO 
-- Integrante 3: GABRIELA POVEDA
-- Curso: BASES DE DATOS 1
-- Fecha: 19/05/2026
-- Variante asignada por el docente (1, 2, 3 o 4): 3
-- Tag de ejecución final (ejemplo: P03_FINAL): P03_FINAL

DEFINE p_variant_id = 1
DEFINE p_execution_tag = 'P03_FINAL'

PROMPT ===== 0. VERIFICACIÓN DE LA VARIANTE ASIGNADA =====
SELECT
    variant_id,
    variant_name,
    excluded_department_id,
    min_years_service,
    recent_job_history_months,
    gap_high_threshold_pct,
    gap_mid_threshold_pct,
    raise_high_pct,
    raise_mid_pct,
    raise_low_pct,
    max_salary_vs_avg_pct,
    notes
FROM t1_variants
WHERE variant_id = &p_variant_id;



PROMPT ===== 1. CONSULTA DIAGNÓSTICA =====
-- La consulta diagnóstica permite analizar salarios, 
-- antigüedad y comportamiento salarial por departamento. 
-- También identifica historial reciente y ranking salarial 
-- para apoyar la decisión de empleados elegibles.

WITH dept_stats AS ( 
    SELECT 
        department_id, 
        AVG(salary) dept_avg_salary, 
        MAX(salary) dept_max_salary, 
        COUNT(*) dept_employee_count 
    FROM t1_employees 
    GROUP BY department_id 
), 
recent_history AS ( 
    SELECT DISTINCT employee_id 
    FROM t1_job_history 
    WHERE MONTHS_BETWEEN(SYSDATE, end_date) <= 24 
) 
SELECT 
    e.employee_id, 
    e.first_name, 
    e.last_name, 
    e.job_id, 
    e.manager_id, 
    e.department_id, 
    d.department_name, 
    e.salary, 
    e.hire_date,
    ROUND( 
        MONTHS_BETWEEN(SYSDATE,e.hire_date)/12, 2 
    ) AS years_service, 
    ROUND(ds.dept_avg_salary,2) 
        AS dept_avg_salary, 
    ds.dept_max_salary, 
    ds.dept_employee_count, 
    ROUND( 
        ( 
           (ds.dept_avg_salary - e.salary)/ ds.dept_avg_salary 
        ) * 100, 2 
    ) AS pct_gap_to_avg, 
    CASE 
        WHEN rh.employee_id IS NOT NULL
            THEN 'SI' 
        ELSE 'NO' 
    END AS recent_job_history_flag, 
    DENSE_RANK() OVER( 
        PARTITION BY e.department_id 
        ORDER BY e.salary DESC 
    ) AS salary_rank_in_department 
FROM t1_employees e 
INNER JOIN t1_departments d 
ON e.department_id = d.department_id 
INNER JOIN dept_stats ds 
ON e.department_id = ds.department_id 
LEFT JOIN recent_history rh 
ON e.employee_id = rh.employee_id 
ORDER BY e.department_id;

PROMPT ===== 2. DECISIÓN DE ELEGIBLES =====

-- Se aplicaron las reglas de la variante 
-- Se excluyó el departamento 100 y empleados con menos de 4 años de antigüedad. 
-- Los empleados restantes fueron marcados como elegibles.  


WITH dept_stats AS ( 
    SELECT 
        department_id, 
        AVG(salary) dept_avg_salary, 
        MAX(salary) dept_max_salary, 
        COUNT(*) dept_employee_count 
    FROM t1_employees 
    GROUP BY department_id 
) 
SELECT 
    e.employee_id, 
    e.first_name, 
    e.last_name, 
    e.department_id, 
    d.department_name, 
    e.salary, 
    ROUND( 
        MONTHS_BETWEEN(SYSDATE,e.hire_date)/12, 2 
    ) AS years_service, 
    ROUND(ds.dept_avg_salary,2) 
        AS dept_avg_salary, 
    ds.dept_max_salary, 
    ds.dept_employee_count, 
    ROUND( 
        ( 
            (ds.dept_avg_salary - e.salary) 
            / ds.dept_avg_salary 
        ) * 100, 2 
    ) AS pct_gap_to_avg, 
    'NO' AS recent_job_history_flag, 
    'NO' AS manager_or_exec_flag, 
    CASE 
        WHEN e.department_id = 100 
            THEN 'NO_ELEGIBLE' 
        WHEN MONTHS_BETWEEN(SYSDATE,e.hire_date)/12 < 4 
            THEN 'NO_ELEGIBLE' 
        ELSE 'ELEGIBLE' 
    END AS eligibility_flag, 
    CASE 
        WHEN e.department_id = 100 
            THEN 'DEPTO_EXCLUIDO' 
        WHEN MONTHS_BETWEEN(SYSDATE,e.hire_date)/12 < 4 
            THEN 'ANTIGUEDAD_INSUFICIENTE' 
        ELSE 'NINGUNA' 
    END AS exclusion_reason, 
    7 AS adjustment_pct, 
    'AJUSTE_ALTO' AS rule_applied 
FROM t1_employees e 
INNER JOIN t1_departments d 
ON e.department_id = d.department_id 
INNER JOIN dept_stats ds 
ON e.department_id = ds.department_id 
ORDER BY e.department_id;

PROMPT ===== 3. PREVALIDACIÓN =====
SELECT  
COUNT(*) total_eligible_employees,   
SUM(salary) total_salary_before,   
SUM(salary * 1.07) total_salary_after,   
SUM((salary * 1.07) - salary)  
   AS total_increment  
FROM t1_employees  
WHERE department_id <> 100  
AND MONTHS_BETWEEN(SYSDATE,hire_date)/12 >= 4;  
SELECT  
employee_id,  
department_id,  
salary salary_before,  
salary * 1.07 salary_after,  
7 adjustment_pct,  
'AJUSTE_ALTO' rule_applied  
FROM t1_employees  
WHERE department_id <> 100  
AND MONTHS_BETWEEN(SYSDATE,hire_date)/12 >= 4;  
SELECT  
d.department_id,  
d.department_name,  
ROUND(AVG(e.salary),2)  
   AS dept_avg_salary,  
MAX(e.salary)  
   AS dept_max_salary,  
ROUND(AVG(e.salary) * 1.18,2)  
   AS max_allowed_salary_by_variant  
FROM t1_employees e  
INNER JOIN t1_departments d ON e.department_id = d.department_id  
GROUP BY d.department_id, d.department_name; 

PROMPT ===== 4. EJECUCIÓN TRANSACCIONAL =====

SAVEPOINT sv_before_adjustment;

-- 4.1 ACTUALIZACIÓN DE SALARIOS
 
UPDATE t1_employees  
SET salary = salary * 1.07  
WHERE department_id <> 100  
AND MONTHS_BETWEEN(SYSDATE,hire_date)/12 >= 4;  


-- 4.2 INSERCIÓN EN AUDITORÍA
INSERT INTO audit_salary_adjustments_t1 ( 
    audit_id, execution_tag,
    variant_id, employee_id,
    department_id,
    salary_before,
    salary_after,
    pct_gap_to_avg_before,
    rule_applied, executed_by,
    executed_at, 
    notes )  
SELECT  
AUDIT_SALARY_ADJ_T1_SEQ.NEXTVAL,  
'&p_execution_tag',  
&p_variant_id,  
employee_id,  
department_id,  
salary / 1.07,  
salary,  
0,  
'AJUSTE_ALTO',  
USER,  
SYSDATE,  
'Ajuste salarial variante 3'  
FROM t1_employees  
WHERE department_id <> 100  
AND MONTHS_BETWEEN(SYSDATE,hire_date)/12 >= 4;  

-- 4.2 VALIDACIÒN INTERMEDIA
SELECT  
employee_id, 
department_id,  
salary current_salary,  
ROUND(salary / 1.07,2)  
   AS original_salary,  
ROUND(  
   AVG(salary)  
   OVER(PARTITION BY department_id) * 1.18,  2  
) AS allowed_max_salary,  
'CUMPLE' AS validation_status  
FROM t1_employees;  



-- 4.4 CONTROL TRANSACCIONAL
COMMIT;  
-- Se realizó COMMIT porque los datos actualizados cumplen las condiciones de la variante y los topes salariales establecidos.  

 




-- ============================================================

PROMPT ===== 5. VALIDACIÓN POSTERIOR =====

-- SALIDA 1. 
SELECT  
employee_id,  
department_id,  
salary_before,  
salary_after,  
execution_tag  
FROM audit_salary_adjustments_t1  
WHERE execution_tag = '&p_execution_tag';  


--
-- SALIDA 2. Resumen económico final
SELECT  
COUNT(*) total_rows_audited,  
SUM(salary_before)  
   total_salary_before,  
SUM(salary_after)  
   total_salary_after,  
SUM(salary_after - salary_before)  
   total_increment  
FROM audit_salary_adjustments_t1  
WHERE execution_tag = '&p_execution_tag';  

-- SALIDA 3. Validación de topes
SELECT  
employee_id,  
department_id,  
salary_after,  
ROUND(  
   AVG(salary_after)  
   OVER(PARTITION BY department_id) * 1.18, 2  
) AS allowed_max_salary,  
'VALIDO' AS top_limit_status  
FROM audit_salary_adjustments_t1  
WHERE execution_tag = '&p_execution_tag';  
--
-- SALIDA 4. Auditoría generada
SELECT  
audit_id,  
execution_tag,  
variant_id,  
employee_id,  
department_id,  
salary_before,  
salary_after,  
rule_applied,  
executed_by,  
executed_at  
FROM audit_salary_adjustments_t1  
WHERE execution_tag = '&p_execution_tag';  



-- ============================================================
-- 6. JUSTIFICACIÓN TÉCNICA

-- ATOMICIDAD: La transacción asegura que todos los cambios se ejecuten completamente o no se ejecuten.  

 

-- CONSISTENCIA: Los datos se mantienen válidos porque solo se actualizaron empleados elegibles.  

 

-- AISLAMIENTO: Oracle controla que otras sesiones no vean cambios sin confirmar durante la transacción.  

 

-- DURABILIDAD: Después del COMMIT los cambios quedan almacenados permanentemente en la base de datos.  

 

-- USO DE SAVEPOINT/ROLLBACK: El SAVEPOINT permite regresar al estado anterior si ocurre algún error en la actualización.  


PROMPT ===== Fin de plantilla =====
