// =====================================================================
// UNIVERSIDAD EL BOSQUE - BASES DE DATOS 2
// TALLER MQL - CONSULTAS, AGREGACIÓN E ÍNDICES EN MONGODB
// Docente: Ing., Esp., M.Ed. Christian Felipe Duarte
// Integrantes: Juan Diego Lopez Galvis / Dylan Arturo Mancipe Celis / Gabriela Poveda Garcia


use("sample_mflix");


// PUNTO 1
// Películas Drama entre 2000 y 2010 con imdb.rating >= 8.
// Se busca "Drama" dentro del array genres, el año con un rango y el
// rating con $gte. Se proyecta sin _id, se ordena por rating
// descendente y se limita a 10. Luego se cuenta el total.

db.movies.find(
  { genres: "Drama", year: { $gte: 2000, $lte: 2010 }, "imdb.rating": { $gte: 8 } },
  { _id: 0, title: 1, year: 1, "imdb.rating": 1 }
).sort({ "imdb.rating": -1 }).limit(10);

db.movies.countDocuments(
  { genres: "Drama", year: { $gte: 2000, $lte: 2010 }, "imdb.rating": { $gte: 8 } }
);



// PUNTO 2
// Películas con Tom Hanks cuyo director no sea Steven Spielberg.
// cast y directors son arrays. $ne en un array devuelve los documentos
// donde ningún elemento es "Steven Spielberg".

db.movies.find(
  { cast: "Tom Hanks", directors: { $ne: "Steven Spielberg" } },
  { _id: 0, title: 1, year: 1, directors: 1 }
);



// PUNTO 3
// Películas con exactamente 3 géneros que incluyan Comedy y Romance.
// $size: 3 exige que el array tenga 3 elementos exactos.
// $all exige que contenga Comedy Y Romance (con $in bastaría uno).

db.movies.find(
  { genres: { $size: 3, $all: ["Comedy", "Romance"] } },
  { _id: 0, title: 1, genres: 1 }
);



// PUNTO 4
// Películas sin el campo rated, o con rated "UNRATED" o "NOT RATED".
// $or une las dos condiciones: el campo no existe o su valor está en
// la lista. Luego se cuenta el total.

db.movies.find(
  { $or: [ { rated: { $exists: false } }, { rated: { $in: ["UNRATED", "NOT RATED"] } } ] },
  { _id: 0, title: 1, rated: 1 }
);

db.movies.countDocuments(
  { $or: [ { rated: { $exists: false } }, { rated: { $in: ["UNRATED", "NOT RATED"] } } ] }
);



// PUNTO 5
// Títulos que empiezan por "The" y terminan en "Man".
// ^ marca el inicio, .* cualquier cosa en medio y $ el final.
// La opción "i" ignora mayúsculas y minúsculas.

db.movies.find(
  { title: { $regex: "^the.*man$", $options: "i" } },
  { _id: 0, title: 1 }
);


// PUNTO 6
// Por género: número de películas, rating promedio (2 decimales) y
// rating máximo. Solo géneros con más de 500 películas.
// 1. $match deja solo ratings numéricos (quita los "").
// 2. $unwind crea un documento por cada género.
// 3. $group calcula conteo, promedio y máximo por género.
// 4. $match deja los géneros con más de 500 películas.
// 5. $project redondea el promedio y $sort ordena descendente.

db.movies.aggregate([
  { $match: { "imdb.rating": { $type: "number" } } },
  { $unwind: "$genres" },
  { $group: {
      _id: "$genres",
      num_peliculas: { $sum: 1 },
      promedio: { $avg: "$imdb.rating" },
      maximo: { $max: "$imdb.rating" }
  } },
  { $match: { num_peliculas: { $gt: 500 } } },
  { $project: { num_peliculas: 1, promedio: { $round: ["$promedio", 2] }, maximo: 1 } },
  { $sort: { promedio: -1 } }
]);

// PUNTO 7
// Top 5 directores con más películas con rating >= 7.5 (mínimo 5).
// 1. $match filtra rating >= 7.5.
// 2. $unwind separa los directores.
// 3. $group cuenta por director y guarda los títulos con $push.
// 4. $match exige mínimo 5 películas.
// 5. $sort y $limit dejan los 5 primeros.
// 6. $project con $slice muestra solo 3 títulos.

db.movies.aggregate([
  { $match: { "imdb.rating": { $gte: 7.5 } } },
  { $unwind: "$directors" },
  { $group: { _id: "$directors", cantidad: { $sum: 1 }, titulos: { $push: "$title" } } },
  { $match: { cantidad: { $gte: 5 } } },
  { $sort: { cantidad: -1 } },
  { $limit: 5 },
  { $project: { cantidad: 1, titulos: { $slice: ["$titulos", 3] } } }
]);

// PUNTO 8
// Número de películas por década desde 1950.
// La década se calcula como year - (year % 10). Ej: 1987 -> 1980.
// Se filtra year numérico porque algunos años están como texto.

db.movies.aggregate([
  { $match: { year: { $type: "number", $gte: 1950 } } },
  { $group: {
      _id: { $subtract: ["$year", { $mod: ["$year", 10] }] },
      cantidad: { $sum: 1 }
  } },
  { $sort: { _id: 1 } }
]);


// PUNTO 9
// Top 10 películas más comentadas.
// 1. $group cuenta los comentarios por movie_id.
// 2. $sort y $limit dejan las 10 con más comentarios.
// 3. $lookup trae la película desde movies.
// 4. $unwind convierte el array del $lookup en objeto.
// 5. $project muestra título, año y número de comentarios.

db.comments.aggregate([
  { $group: { _id: "$movie_id", num_comentarios: { $sum: 1 } } },
  { $sort: { num_comentarios: -1 } },
  { $limit: 10 },
  { $lookup: { from: "movies", localField: "_id", foreignField: "_id", as: "pelicula" } },
  { $unwind: "$pelicula" },
  { $project: { _id: 0, titulo: "$pelicula.title", anio: "$pelicula.year", num_comentarios: 1 } }
]);


// PUNTO 10
// Usuarios con más de 250 comentarios, con fecha del primero y último.
// Se agrupa por email: $min da el primer comentario y $max el último.
// Luego se filtran los que tienen más de 250.

db.comments.aggregate([
  { $group: {
      _id: "$email",
      total: { $sum: 1 },
      primer_comentario: { $min: "$date" },
      ultimo_comentario: { $max: "$date" }
  } },
  { $match: { total: { $gt: 250 } } },
  { $sort: { total: -1 } }
]);




// PUNTO 11
// Crear peliculas_pareja con las películas de 2015 y un campo
// categoria calculado con $switch:
// "Alta" si rating >= 7.5, "Media" si >= 6, "Baja" en otro caso.
// Se filtran ratings numéricos y $out guarda el resultado en la
// colección nueva.

db.movies.aggregate([
  { $match: { year: 2015, "imdb.rating": { $type: "number" } } },
  { $project: {
      title: 1,
      genres: 1,
      rating: "$imdb.rating",
      categoria: {
        $switch: {
          branches: [
            { case: { $gte: ["$imdb.rating", 7.5] }, then: "Alta" },
            { case: { $gte: ["$imdb.rating", 6] }, then: "Media" }
          ],
          default: "Baja"
        }
      }
  } },
  { $out: "peliculas_pareja" }
]);

db.peliculas_pareja.find();



// PUNTO 12
// Agregar revisado: true y sumar 0.1 al rating de la categoría "Media".
// $set agrega el campo y $inc incrementa el rating.
// El resultado muestra matchedCount y modifiedCount.

db.peliculas_pareja.updateMany(
  { categoria: "Media" },
  { $set: { revisado: true }, $inc: { rating: 0.1 } }
);



// PUNTO 13
// Eliminar las películas de categoría "Baja".
// El resultado muestra deletedCount (documentos borrados).

db.peliculas_pareja.deleteMany({ categoria: "Baja" });



// PUNTO 14
// Comparar la consulta del punto 1 antes y después de un índice.
// Índice con la regla ESR:
//   E (Equality) genres       -> genres = "Drama"
//   S (Sort)     imdb.rating  -> se ordena por rating
//   R (Range)    year         -> año entre 2000 y 2010
// En cada explain revisar: totalDocsExamined, executionTimeMillis y la
// etapa del winningPlan (COLLSCAN antes, IXSCAN después).


// 14.1 Antes del índice
db.movies.find(
  { genres: "Drama", year: { $gte: 2000, $lte: 2010 }, "imdb.rating": { $gte: 8 } }
).sort({ "imdb.rating": -1 }).limit(10).explain("executionStats");

// 14.2 Crear el índice
db.movies.createIndex({ genres: 1, "imdb.rating": -1, year: 1 });

// 14.3 Después del índice
db.movies.find(
  { genres: "Drama", year: { $gte: 2000, $lte: 2010 }, "imdb.rating": { $gte: 8 } }
).sort({ "imdb.rating": -1 }).limit(10).explain("executionStats");

// 14.4 Eliminar el índice
db.movies.dropIndex({ genres: 1, "imdb.rating": -1, year: 1 });

