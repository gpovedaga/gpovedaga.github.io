--------------------------------------------------------------------------------
-- UNIVERSIDAD EL BOSQUE — INGENIERIA DE SISTEMAS
-- Asignatura: Bases de Datos 2
-- Docente: Ing., Esp., M.Ed. Christian Felipe Duarte
--
-- TALLER PL/SQL — PLANTILLA DE ENTREGA
--
-- GRUPO No.: ____
-- INTEGRANTES: 1) Dylan Arturo Mancipe Celis
--              2) Juan Diego Lopez Galvis
--              3) Gabriela Poveda Garcia
-- FECHA DE ENTREGA: 03/10/2026
--------------------------------------------------------------------------------
--
-- COMO TRABAJAR
--   1. Ejecute primero, completo, el script 01_esquema_inventario.sql
--   2. Desarrolle cada punto en la seccion correspondiente de este archivo
--   3. No borre los encabezados de cada ejercicio ni cambie los nombres de los
--      objetos solicitados. La revision los busca por nombre: un objeto correcto
--      con otro nombre se califica como no entregado.
--   4. Los esqueletos de la Parte 5 no incluyen la clausula de disparo. Definirla
--      hace parte del ejercicio, de modo que esos bloques no compilan tal como se
--      entregan.
--
-- DISTRIBUCION DEL PUNTAJE                                     Total: 50 puntos
--   Parte 1  Procedimientos almacenados .................  8 puntos
--   Parte 2  Funciones ...................................  8 puntos
--   Parte 3  Cursores .................................... 10 puntos
--   Parte 4  Manejo de excepciones .......................  9 puntos
--   Parte 5  Disparadores ................................ 10 puntos
--   Parte 6  Caso integrador .............................  5 puntos
--
-- CRITERIOS DE EVALUACION
--   Correccion tecnica ....... 40%   El objeto compila y cumple el enunciado
--   Justificacion ............ 40%   Las decisiones de diseno estan argumentadas
--   Analisis operacional ..... 20%   Se anticipa el comportamiento ante
--                                    concurrencia, volumen y error
--
--   Cada objeto debe incluir su justificacion en el espacio marcado. Un ejercicio
--   sin justificacion obtiene como maximo el 40% de su puntaje aunque funcione.
--   Una justificacion que confunde la causa con el efecto no obtiene puntaje.
--   Describir lo que hace el codigo, sin argumentar por que se eligio esa
--   construccion y no otra, equivale a no justificar.
--
-- ENTREGA
--   Este archivo renombrado como TALLER_PLSQL_GRUPO_<n>.sql, junto con un
--   documento que contenga las salidas de DBMS_OUTPUT de cada bloque ejecutado.
--   Ambos archivos deben incluir los nombres de los tres integrantes.
--
-- SUSTENTACION
--   20 minutos por grupo. Los tres integrantes deben poder explicar cualquier
--   parte del codigo, no solamente la que desarrollaron.
--------------------------------------------------------------------------------

SET SERVEROUTPUT ON SIZE UNLIMITED

--==============================================================================
-- PARTE 1 — PROCEDIMIENTOS ALMACENADOS                        (8 puntos / 75 min)
--==============================================================================

------------------------------------------------------------------- 1.1 (2 pts)
-- SP_REGISTRAR_PRODUCTO
-- Registra un producto nuevo. Debe asignar el identificador desde SEQ_PRODUCTO,
-- validar que el precio de venta supere el costo unitario, verificar que la
-- categoria exista y manejar el caso de codigo duplicado. Devuelve el
-- identificador generado.
-------------------------------------------------------------------------------
-- JUSTIFICACION:
-- Se valida con IF + DBMS_OUTPUT + RETURN porque el enunciado solo pide validar
-- y las excepciones propias son tema de la parte 4. RETURN evita gastar la
-- secuencia y hacer el INSERT. Costo: el procedimiento termina "bien" aunque no
-- cree nada, por eso p_id_producto queda en NULL y el llamador debe revisarlo.
-- Los nulos se validan primero porque comparar con NULL da NULL y el IF no se
-- dispararia. La secuencia va al final para no perder numeros.
-- La categoria se consulta antes del INSERT (la FK la respalda); el codigo
-- duplicado NO, porque un SELECT previo tiene condicion de carrera entre dos
-- sesiones. La garantia es UK_PRODUCTO_CODIGO, y se captura DUP_VAL_ON_INDEX.
-- El INSTR/RAISE evita confundirlo con un choque de la PK (SEQ_PRODUCTO estaba
-- desincronizada), que si no quedaria disfrazado de "codigo duplicado".
-- Los huecos en los ids son normales: la secuencia no se devuelve con ROLLBACK.
-- No hay COMMIT (la transaccion es del llamador) ni WHEN OTHERS.
--
CREATE OR REPLACE PROCEDURE SP_REGISTRAR_PRODUCTO (
    p_codigo        IN  VARCHAR2,
    p_nombre        IN  VARCHAR2,
    p_id_categoria  IN  NUMBER,
    p_precio        IN  NUMBER,
    p_costo         IN  NUMBER,
    p_stock_minimo  IN  NUMBER DEFAULT 0,
    p_id_producto   OUT NUMBER
) IS
    vn_existe NUMBER;
BEGIN
    p_id_producto := NULL;
    IF p_codigo IS NULL OR p_nombre IS NULL OR p_id_categoria IS NULL
       OR p_precio IS NULL OR p_costo IS NULL OR p_stock_minimo IS NULL THEN
       DBMS_OUTPUT.PUT_LINE('Todos los parametros son obligatorios, por lo cual el producto no se creó');
       RETURN;
    END IF;
    IF p_precio <= 0 OR p_costo <=0  THEN
       DBMS_OUTPUT.PUT_LINE('El precio y costo no pueden ser menores o iguales a 0, por lo cual el producto no se creó');
       RETURN;
    END IF;
    IF p_stock_minimo < 0 THEN
       DBMS_OUTPUT.PUT_LINE('El stock minimo no puede ser menor a cero, por lo cual el producto no se creó');
       RETURN;
    END IF;
    IF p_precio <= p_costo THEN
       DBMS_OUTPUT.PUT_LINE('El precio debe ser mayor que el costo unitario, por lo cual el producto no se creó');
       RETURN;
    END IF;

    SELECT COUNT(*) 
    INTO vn_existe
    FROM 
    CATEGORIA
    WHERE id_categoria = p_id_categoria;

    IF vn_existe = 0 THEN 
        DBMS_OUTPUT.PUT_LINE('La categoria no existe, por lo cual el producto no se creó');
        RETURN;
    END IF;

    p_id_producto := SEQ_PRODUCTO.NEXTVAL;
    INSERT INTO PRODUCTO (id_producto, codigo, nombre, id_categoria,
                          precio_unitario, costo_unitario, stock_minimo, activo)
    VALUES (p_id_producto, p_codigo, p_nombre, p_id_categoria,
            p_precio, p_costo, p_stock_minimo, 'S');
    DBMS_OUTPUT.PUT_LINE('Producto creado correctamente');
EXCEPTION
    WHEN DUP_VAL_ON_INDEX THEN
        p_id_producto := NULL;
        IF INSTR(UPPER(SQLERRM), 'UK_PRODUCTO_CODIGO') > 0 THEN
            DBMS_OUTPUT.PUT_LINE('Ya existe un producto con el codigo ' || p_codigo || ', por lo cual el producto no se creó');
        ELSE
            RAISE;
        END IF;
END SP_REGISTRAR_PRODUCTO;
/
-- PRUEBA 
-- LE PUSIMOS ROLLBACK AL FINAL PARA NO AFECTAR LAS DEMAS PRUEBAS
VARIABLE vn_id NUMBER
ALTER SEQUENCE SEQ_PRODUCTO RESTART START WITH 1016;
-- 1. Caso perfecto: debe devolver un id (1016 o mas)
EXEC SP_REGISTRAR_PRODUCTO('PP-0005', 'Prueba', 1, 14000, 10000, 5, :vn_id)
PRINT vn_id

-- 2. Precio igual al costo: mensaje, id NULL
EXEC SP_REGISTRAR_PRODUCTO('PP-0002', 'Prueba', 1, 10000, 10000, 5, :vn_id)
PRINT vn_id

-- 3. Categoria inexistente
EXEC SP_REGISTRAR_PRODUCTO('PP-0003', 'Prueba', 99, 14000, 10000, 5, :vn_id)
PRINT vn_id

-- 4. Codigo duplicado (HM-0001 ya existe)
EXEC SP_REGISTRAR_PRODUCTO('HM-0001', 'Prueba', 1, 14000, 10000, 5, :vn_id)
PRINT vn_id

-- 5. Costo cero
EXEC SP_REGISTRAR_PRODUCTO('PP-0005', 'Prueba', 1, 5000, 0, 5, :vn_id)
PRINT vn_id

-- 6. Stock minimo negativo
EXEC SP_REGISTRAR_PRODUCTO('PP-0006', 'Prueba', 1, 14000, 10000, -3, :vn_id)
PRINT vn_id

ROLLBACK;
------------------------------------------------------------------- 1.2 (3 pts)
-- SP_AJUSTAR_STOCK
-- Registra una ENTRADA, SALIDA o AJUSTE de inventario sobre una bodega.
-- Debe actualizar EXISTENCIA e insertar el registro en MOVIMIENTO_INVENTARIO,
-- devolviendo el saldo resultante.
--   * Si la combinacion bodega-producto no existe y el tipo es ENTRADA, crearla
--   * Si el tipo es SALIDA y no existe la combinacion, rechazar la operacion
--   * Una SALIDA nunca puede dejar la existencia en negativo
-- Proteja la lectura de la existencia frente a modificaciones concurrentes.
-------------------------------------------------------------------------------
-- JUSTIFICACION:
-- Mismo criterio que 1.1: IF + DBMS_OUTPUT + RETURN, y p_saldo_final queda en
-- NULL si se rechaza. Todas las validaciones van antes de cualquier DML, asi un
-- rechazo no deja cambios a medias.
-- La existencia se lee con SELECT ... FOR UPDATE: sin el bloqueo, dos SALIDA
-- simultaneas leen el mismo saldo y la segunda pisa a la primera (lost update).
-- El bloqueo dura hasta el COMMIT/ROLLBACK del llamador, tambien tras un rechazo.
-- Si la fila no existe no hay nada que bloquear: dos ENTRADA simultaneas pueden
-- intentar crearla; la PK decide y la que pierde suma con un UPDATE.
-- Solo ENTRADA crea la combinacion (enunciado); AJUSTE tampoco, por coherencia.
-- La SALIDA se compara con el saldo antes de restar; el CHECK de EXISTENCIA es
-- solo una red de seguridad.
-- AJUSTE = conteo fisico: deja la existencia en la cantidad indicada y la
-- bitacora guarda esa cantidad. Como ck_mov_cantidad exige > 0, no se puede
-- ajustar a cero.
-- MAX(activa) distingue bodega inexistente (NULL) de inactiva sin NO_DATA_FOUND
-- Sin COMMIT: existencia y movimiento se confirman o se descartan juntos
--
CREATE OR REPLACE PROCEDURE SP_AJUSTAR_STOCK (
    p_id_producto  IN  NUMBER,
    p_id_bodega    IN  NUMBER,
    p_tipo         IN  VARCHAR2,
    p_cantidad     IN  NUMBER,
    p_observacion  IN  VARCHAR2 DEFAULT NULL,
    p_saldo_final  OUT NUMBER
) IS
    vn_existe NUMBER;
    vc_activa CHAR(1);
    vn_actual  NUMBER;
    vn_nuevo NUMBER;
    vb_hay BOOLEAN := TRUE;
BEGIN
    p_saldo_final := NULL;

    IF p_id_producto IS NULL OR p_id_bodega IS NULL OR p_tipo IS NULL 
       OR  p_cantidad IS NULL THEN
       DBMS_OUTPUT.PUT_LINE('Producto, bodega, tipo y cantidad son obligatorios, por lo cual el movimiento no se registro');
       RETURN;
    END IF;
    IF p_tipo NOT IN ('ENTRADA', 'SALIDA', 'AJUSTE') THEN 
       DBMS_OUTPUT.PUT_LINE('El tipo debe ser mayor a cero, por lo cual el movimiento no se registro');
       RETURN;
    END IF;
    IF p_cantidad <= 0 THEN
       DBMS_OUTPUT.PUT_LINE('La cantidad debe de ser mayor a cero, por lo cual el movimiento no se registro');
    RETURN;
    END IF;

    SELECT COUNT(*)
    INTO vn_existe
    FROM PRODUCTO
    WHERE id_producto = p_id_producto;

    IF vn_existe = 0 THEN 
       DBMS_OUTPUT.PUT_LINE('El producto no existe, por lo cual el movimiento no se registro');
       RETURN;
    END IF;

    SELECT MAX(activa)
    INTO vc_activa
    FROM BODEGA
    WHERE id_bodega = p_id_bodega;

    IF vc_activa IS NULL THEN 
       DBMS_OUTPUT.PUT_LINE('La bodega no existe, por lo cual el movimiento no se registro');
       RETURN;
    END IF;

    BEGIN
        SELECT cantidad
        INTO vn_actual
        FROM EXISTENCIA
        WHERE id_bodega = p_id_bodega
          AND id_producto = p_id_producto
        FOR UPDATE;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            vb_hay := FALSE;
    END;

    IF NOT vb_hay AND p_tipo <> 'ENTRADA' THEN
       DBMS_OUTPUT.PUT_LINE('No existe el producto en esa bodega y solo una ENTRADA puede crearlo, por lo cual el movimiento no se registro');
       RETURN;
    END IF;

    IF p_tipo = 'ENTRADA' THEN
       vn_nuevo := NVL(vn_actual, 0) + p_cantidad;
    ELSIF p_tipo = 'SALIDA' THEN
       IF p_cantidad > vn_actual THEN
          DBMS_OUTPUT.PUT_LINE('La salida (' || p_cantidad || ') supera la existencia (' || vn_actual || '), por lo cual el movimiento no se registro');
          RETURN;
       END IF;
       vn_nuevo := vn_actual - p_cantidad;
    ELSE
       vn_nuevo := p_cantidad;   
    END IF;

    IF vb_hay THEN
       UPDATE EXISTENCIA
       SET cantidad = vn_nuevo
       WHERE id_bodega = p_id_bodega
         AND id_producto = p_id_producto;
    ELSE
       BEGIN
           INSERT INTO EXISTENCIA (id_bodega, id_producto, cantidad)
           VALUES (p_id_bodega, p_id_producto, p_cantidad);
           vn_nuevo := p_cantidad;
       EXCEPTION
           WHEN DUP_VAL_ON_INDEX THEN   
               UPDATE EXISTENCIA
               SET cantidad = cantidad + p_cantidad
               WHERE id_bodega = p_id_bodega
                 AND id_producto = p_id_producto
               RETURNING cantidad INTO vn_nuevo;
       END;
    END IF;

    INSERT INTO MOVIMIENTO_INVENTARIO (id_movimiento, id_producto, id_bodega,
                                       tipo, cantidad, observacion)
    VALUES (SEQ_MOVIMIENTO.NEXTVAL, p_id_producto, p_id_bodega,
            p_tipo, p_cantidad, p_observacion);

    p_saldo_final := vn_nuevo;
    DBMS_OUTPUT.PUT_LINE('Movimiento registrado. Saldo resultante: ' || vn_nuevo);
END SP_AJUSTAR_STOCK;
/
-- PRUEBA 
-- LE PUSIMOS ROLLBACK AL FINAL PARA NO AFECTAR LAS DEMAS PRUEBAS
VARIABLE vn_saldo NUMBER

-- 1. ENTRADA sobre existencia existente (1001 en bodega 1 tiene 120): saldo 130
EXEC SP_AJUSTAR_STOCK(1001, 1, 'ENTRADA', 10, 'Prueba', :vn_saldo)
PRINT vn_saldo

-- 2. SALIDA valida: saldo 100
EXEC SP_AJUSTAR_STOCK(1001, 1, 'SALIDA', 30, 'Prueba', :vn_saldo)
PRINT vn_saldo

-- 3. SALIDA que dejaria negativo: rechazo, saldo NULL
EXEC SP_AJUSTAR_STOCK(1001, 1, 'SALIDA', 500, 'Prueba', :vn_saldo)
PRINT vn_saldo

-- 4. SALIDA sin combinacion bodega-producto (1015 no esta en bodega 4): rechazo
EXEC SP_AJUSTAR_STOCK(1015, 4, 'SALIDA', 5, 'Prueba', :vn_saldo)
PRINT vn_saldo

-- 5. ENTRADA que crea la combinacion (1015 en bodega 3): saldo 20
EXEC SP_AJUSTAR_STOCK(1015, 3, 'ENTRADA', 20, 'Prueba', :vn_saldo)
PRINT vn_saldo

-- 6. AJUSTE (conteo fisico): deja la existencia en 95
EXEC SP_AJUSTAR_STOCK(1001, 1, 'AJUSTE', 95, 'Conteo', :vn_saldo)
PRINT vn_saldo

-- 7. Bodega inactiva (5), producto inexistente, tipo invalido, cantidad cero
EXEC SP_AJUSTAR_STOCK(1001, 5, 'ENTRADA', 5, NULL, :vn_saldo)
EXEC SP_AJUSTAR_STOCK(9999, 1, 'ENTRADA', 5, NULL, :vn_saldo)
EXEC SP_AJUSTAR_STOCK(1001, 1, 'TRASLADO', 5, NULL, :vn_saldo)
EXEC SP_AJUSTAR_STOCK(1001, 1, 'ENTRADA', 0, NULL, :vn_saldo)

ROLLBACK;
------------------------------------------------------------------- 1.3 (3 pts)
-- SP_CREAR_PEDIDO
-- Crea la cabecera de un pedido en estado BORRADOR y devuelve el identificador
-- generado. Debe rechazar clientes inactivos y clientes sin cupo de credito
-- disponible, con mensajes distinguibles entre si.
-------------------------------------------------------------------------------
-- JUSTIFICACION:
-- Mismo criterio que 1.1: IF + DBMS_OUTPUT + RETURN, y p_id_pedido queda en NULL
-- si se rechaza. Se distinguen tres casos con mensaje propio (no existe,
-- inactivo, sin cupo) y el orden importa: un cliente inactivo se rechaza como
-- inactivo aunque tenga cupo.
-- El cupo disponible (cupo - saldo) se calcula aqui con un solo SELECT porque
-- FN_CUPO_DISPONIBLE se crea despues, en 2.2; si el procedimiento la llamara
-- quedaria invalido hasta entonces.
-- Un pedido en BORRADOR no consume cupo (el saldo sube al facturar, parte 6), asi
-- que esta validacion es un filtro temprano y no una reserva: no se bloquea al
-- cliente. La validacion definitiva debe repetirse al confirmar el pedido.
-- La secuencia se consume solo despues de validar. Sin COMMIT: lo decide el
-- llamador
--
CREATE OR REPLACE PROCEDURE SP_CREAR_PEDIDO (
    p_id_cliente  IN  NUMBER,
    p_id_pedido   OUT NUMBER
) IS
    vn_existe  NUMBER;
    vc_activo  CHAR(1);
    vn_cupo    NUMBER;
    vn_saldo   NUMBER;
BEGIN
    p_id_pedido := NULL;

    IF p_id_cliente IS NULL THEN
       DBMS_OUTPUT.PUT_LINE('El cliente es obligatorio, por lo cual el pedido no se creo');
       RETURN;
    END IF;

    SELECT COUNT(*)
    INTO vn_existe
    FROM CLIENTE
    WHERE id_cliente = p_id_cliente;

    IF vn_existe = 0 THEN
       DBMS_OUTPUT.PUT_LINE('El cliente ' || p_id_cliente || ' no existe, por lo cual el pedido no se creo');
       RETURN;
    END IF;

    SELECT activo, cupo_credito, saldo_pendiente
    INTO vc_activo, vn_cupo, vn_saldo
    FROM CLIENTE
    WHERE id_cliente = p_id_cliente;

    IF vc_activo = 'N' THEN
       DBMS_OUTPUT.PUT_LINE('El cliente ' || p_id_cliente || ' esta inactivo, por lo cual el pedido no se creo');
       RETURN;
    END IF;

    IF vn_cupo - vn_saldo <= 0 THEN
       DBMS_OUTPUT.PUT_LINE('El cliente ' || p_id_cliente || ' no tiene cupo de credito disponible, por lo cual el pedido no se creo');
       RETURN;
    END IF;

    p_id_pedido := SEQ_PEDIDO.NEXTVAL;

    INSERT INTO PEDIDO (id_pedido, id_cliente, estado)
    VALUES (p_id_pedido, p_id_cliente, 'BORRADOR');

    DBMS_OUTPUT.PUT_LINE('Pedido ' || p_id_pedido || ' creado en estado BORRADOR');
END SP_CREAR_PEDIDO;
/
-- PRUEBA 
-- LE PUSIMOS ROLLBACK AL FINAL PARA NO AFECTAR LAS DEMAS PRUEBAS
VARIABLE v_pedido NUMBER

-- 1. Cliente activo con cupo (501): crea el pedido, id 8 o mas
EXEC SP_CREAR_PEDIDO(501, :v_pedido)
PRINT v_pedido

-- 2. Cliente con poco cupo pero positivo (502: 5.000.000 - 4.700.000): crea
EXEC SP_CREAR_PEDIDO(502, :v_pedido)
PRINT v_pedido

-- 3. Cliente con cupo agotado (505: 1.500.000 - 1.500.000): rechazo
EXEC SP_CREAR_PEDIDO(505, :v_pedido)
PRINT v_pedido

-- 4. Cliente inactivo (506): rechazo con otro mensaje
EXEC SP_CREAR_PEDIDO(506, :v_pedido)
PRINT v_pedido

-- 5. Cliente inexistente y cliente nulo
EXEC SP_CREAR_PEDIDO(999, :v_pedido)
EXEC SP_CREAR_PEDIDO(NULL, :v_pedido)

ROLLBACK;

--==============================================================================
-- PARTE 2 — FUNCIONES (8 puntos / 75 min)
--==============================================================================
------------------------------------------------------------------- 2.1 (2 pts)
-- FN_STOCK_DISPONIBLE
-- Retorna la cantidad disponible de un producto. Si se indica bodega, devuelve
-- el saldo de esa bodega; si p_id_bodega llega nulo, el consolidado de todas.
-- Un producto inexistente debe retornar cero y no una excepcion.
-------------------------------------------------------------------------------
-- JUSTIFICACION:
-- Recorro con un for las filas de existencia del producto y las voy sumando en
-- vn_stock, que empieza en 0. Use for y no select into porque el select into
-- lanza no_data_found cuando no hay filas, y el enunciado dice que un producto
-- inexistente debe dar 0 y no una excepcion: con el for, si no hay filas el
-- ciclo no corre y se devuelve el 0 inicial, sin necesitar un manejador.
-- Una sola consulta sirve para los dos casos: si p_id_bodega es nulo sumo todas
-- las filas (consolidado) y si trae valor solo sumo la de esa bodega. Pude
-- filtrar la bodega en el where, pero asi la logica queda en un solo lugar.
-- Operacion: hay maximo una fila por bodega (la llave primaria es bodega y
-- producto), asi que el ciclo es corto; con muchas bodegas convendria filtrar en
-- el where o usar sum. La lectura no bloquea a nadie, pero el valor puede
-- cambiar justo despues de leerlo, asi que sirve para consultar o validar y no
-- para reservar: el descuento real del stock se hace con for update en
-- sp_ajustar_stock. Solo hace select, por eso tambien se puede llamar desde sql.
CREATE OR REPLACE FUNCTION FN_STOCK_DISPONIBLE (
    p_id_producto IN NUMBER,
    p_id_bodega   IN NUMBER DEFAULT NULL
) RETURN NUMBER IS
    vn_stock NUMBER := 0;
BEGIN
    FOR reg IN (SELECT id_bodega, cantidad
                FROM   EXISTENCIA
                WHERE  id_producto = p_id_producto) LOOP

        IF p_id_bodega IS NULL OR reg.id_bodega = p_id_bodega THEN
            vn_stock := vn_stock + reg.cantidad;
        END IF;

    END LOOP;

    RETURN vn_stock;
END FN_STOCK_DISPONIBLE;
/


SELECT FN_STOCK_DISPONIBLE(1001)    FROM DUAL;  
SELECT FN_STOCK_DISPONIBLE(1001, 2) FROM DUAL;  
SELECT FN_STOCK_DISPONIBLE(1001, 3) FROM DUAL;  
SELECT FN_STOCK_DISPONIBLE(9999)    FROM DUAL;  
------------------------------------------------------------------- 2.2 (2 pts)
-- FN_CUPO_DISPONIBLE
-- Retorna el cupo de credito disponible del cliente, entendido como cupo menos
-- saldo pendiente. Un cliente inactivo retorna cero y el resultado nunca puede
-- ser negativo.
-------------------------------------------------------------------------------
-- JUSTIFICACION:
-- Uso un for sobre el cliente filtrando activo = 'S' en el where. Asi, si el
-- cliente esta inactivo o no existe, el ciclo no corre y la funcion devuelve el
-- 0 inicial: las dos reglas (inactivo da 0, inexistente no da error) salen de la
-- misma condicion, sin select into ni manejador.
-- La resta cupo - saldo solo se hace cuando el cupo es mayor que el saldo. Es
-- necesario porque la tabla no impide que el saldo supere al cupo (solo exige
-- que cada uno sea mayor o igual a 0), entonces la resta podria dar negativo y
-- el enunciado no lo permite
CREATE OR REPLACE FUNCTION FN_CUPO_DISPONIBLE (
    p_id_cliente IN NUMBER
) RETURN NUMBER IS
    vn_cupo NUMBER := 0;
BEGIN
    FOR reg IN (SELECT cupo_credito, saldo_pendiente
                FROM   CLIENTE
                WHERE  id_cliente = p_id_cliente
                AND    activo = 'S') LOOP

        IF reg.cupo_credito > reg.saldo_pendiente THEN
            vn_cupo := reg.cupo_credito - reg.saldo_pendiente;
        END IF;

    END LOOP;

    RETURN vn_cupo;
END FN_CUPO_DISPONIBLE;
/



SELECT FN_CUPO_DISPONIBLE(501)  FROM DUAL;  
SELECT FN_CUPO_DISPONIBLE(502)  FROM DUAL;  
SELECT FN_CUPO_DISPONIBLE(505)  FROM DUAL;  
SELECT FN_CUPO_DISPONIBLE(506)  FROM DUAL;  

------------------------------------------------------------------- 2.3 (3 pts)
-- FN_CALCULAR_DESCUENTO
-- Retorna el VALOR en pesos del descuento aplicable, segun estas reglas
-- acumulables:
-- Monto mayor o igual a 2.000.000 ................. 8%
-- Monto entre 800.000 y 1.999.999 ................. 5%
-- Monto menor a 800.000 ........................... 0%
-- Adicional si el cliente no tiene saldo pendiente . 2%
-- Tope maximo acumulado ........................... 10%
-- La funcion retorna el valor del descuento, no el porcentaje.
-------------------------------------------------------------------------------
-- JUSTIFICACION:
-- Primero saco el porcentaje segun el monto (8%, 5% o 0%). Despues, si el
-- cliente no tiene saldo pendiente, le sumo 2% mas porque los descuentos se
-- acumulan. Si el porcentaje se pasa de 10, lo dejo en 10. Al final multiplico
-- el monto por el porcentaje para devolver los pesos del descuento y no el
-- porcentaje. Si el monto no sirve o el cliente no existe, devuelve 0.
CREATE OR REPLACE FUNCTION FN_CALCULAR_DESCUENTO (
    p_id_cliente IN NUMBER,
    p_monto      IN NUMBER
) RETURN NUMBER IS
    vn_pct       NUMBER := 0;
    vn_descuento NUMBER := 0;
BEGIN
    IF p_monto IS NULL OR p_monto <= 0 THEN
        RETURN 0;
    END IF;

    FOR reg IN (SELECT saldo_pendiente
        FROM   CLIENTE
        WHERE  id_cliente = p_id_cliente) LOOP
        IF p_monto >= 2000000 THEN
            vn_pct := 8;
        ELSIF p_monto >= 800000 THEN
            vn_pct := 5;
        ELSE
            vn_pct := 0;
        END IF;

        IF reg.saldo_pendiente = 0 THEN
            vn_pct := vn_pct + 2;
        END IF;

        IF vn_pct > 10 THEN
            vn_pct := 10;
        END IF;

        vn_descuento := p_monto * vn_pct / 100;

    END LOOP;

    RETURN vn_descuento;
END FN_CALCULAR_DESCUENTO;
/


SELECT FN_CALCULAR_DESCUENTO(503, 2500000) FROM DUAL;  
SELECT FN_CALCULAR_DESCUENTO(501, 2500000) FROM DUAL;  
SELECT FN_CALCULAR_DESCUENTO(501,  900000) FROM DUAL;  
SELECT FN_CALCULAR_DESCUENTO(503,  900000) FROM DUAL;  
SELECT FN_CALCULAR_DESCUENTO(503,  500000) FROM DUAL;  
SELECT FN_CALCULAR_DESCUENTO(501,  500000) FROM DUAL;  
------------------------------------------------------------------- 2.4 (1 pt)
-- Escriba una consulta que liste los clientes activos con su cupo disponible,
-- usando la funcion del punto 2.2, ordenados de mayor a menor.
-- Explique por que una funcion definida por el usuario puede invocarse desde
-- una sentencia SQL y que restriccion debe cumplir para poder hacerlo.
-------------------------------------------------------------------------------
-- RESPUESTA:
-- Se puede porque la funcion devuelve un solo valor, asi que Oracle la trata
-- como una columna mas y la calcula fila por fila.
-- La restriccion es que no puede modificar datos (INSERT, UPDATE, DELETE ni
-- COMMIT), solo consultar. Mi funcion cumple porque solo hace un SELECT.
--
-- SELECT ...
SELECT id_cliente,
       nombre,
       FN_CUPO_DISPONIBLE(id_cliente) AS cupo_disponible
FROM   CLIENTE
WHERE  activo = 'S'
ORDER  BY cupo_disponible DESC;

--==============================================================================
-- PARTE 3 — CURSORES                                         (10 puntos / 90 min)
--==============================================================================

------------------------------------------------------------------- 3.1 (2 pts)
-- Bloque anonimo que recorra, con un CURSOR EXPLICITO, los productos cuyo stock
-- consolidado este por debajo del stock minimo, e imprima un reporte con codigo,
-- nombre, stock actual, stock minimo y unidades faltantes, mas el total de
-- productos en esa condicion.
-- Debe usar OPEN, FETCH y CLOSE de forma explicita. El ciclo FOR implicito no se
-- acepta en este punto.
-------------------------------------------------------------------------------
-- JUSTIFICACION:
-- OPEN/FETCH/CLOSE explicitos, como exige el punto. El EXIT WHEN %NOTFOUND va
-- justo despues del FETCH: si se pusiera al final del bucle, el ultimo FETCH
-- fallido dejaria la fila anterior en el registro y se imprimiria dos veces. El
-- total sale de %ROWCOUNT (antes del CLOSE), sin recorrer de nuevo. Se consulta
-- V_STOCK_CONSOLIDADO en vez de volver a sumar EXISTENCIA: la vista usa LEFT
-- JOIN, por eso tambien aparecen los productos sin existencia (stock 0). CLOSE
-- siempre se ejecuta para liberar el cursor.
DECLARE
    CURSOR c_bajo_minimo IS
        SELECT codigo,
               producto,
               stock_total,
               stock_minimo,
               stock_minimo - stock_total AS unidades_faltantes
        FROM   V_STOCK_CONSOLIDADO
        WHERE  stock_total < stock_minimo
        ORDER  BY unidades_faltantes DESC, codigo;
    vr_prod  c_bajo_minimo%ROWTYPE;
    vn_total NUMBER;
BEGIN
    OPEN c_bajo_minimo;
    DBMS_OUTPUT.PUT_LINE(RPAD('CODIGO', 10) || RPAD('PRODUCTO', 34)
        || LPAD('STOCK', 8) || LPAD('MINIMO', 8) || LPAD('FALTAN', 8));
    LOOP
        FETCH c_bajo_minimo INTO vr_prod;
        EXIT WHEN c_bajo_minimo%NOTFOUND;
        DBMS_OUTPUT.PUT_LINE(RPAD(vr_prod.codigo, 10) || RPAD(vr_prod.producto, 34)
            || LPAD(vr_prod.stock_total, 8) || LPAD(vr_prod.stock_minimo, 8)
            || LPAD(vr_prod.unidades_faltantes, 8));
    END LOOP;
    vn_total := c_bajo_minimo%ROWCOUNT;
    CLOSE c_bajo_minimo;

    IF vn_total = 0 THEN
        DBMS_OUTPUT.PUT_LINE('Ningun producto esta por debajo del stock minimo');
    ELSE
        DBMS_OUTPUT.PUT_LINE('Total de productos bajo el stock minimo: ' || vn_total);
    END IF;
END;
/


------------------------------------------------------------------- 3.2 (2 pts)
-- Bloque anonimo con un CURSOR PARAMETRIZADO que reciba identificador de cliente
-- y un rango de fechas, y muestre los pedidos CONFIRMADOS de ese cliente en ese
-- rango, con su total y la cantidad de lineas de cada pedido.
-- Pruebelo con el cliente 501 entre 2026-01-01 y 2026-12-31.
-- Los parametros deben declararse en el cursor, no tomarse del alcance del bloque.
-------------------------------------------------------------------------------
-- JUSTIFICACION:
-- El cursor recibe cliente y fechas al abrirse, asi la misma declaracion sirve
-- para cualquier cliente o rango y no depende de variables del bloque. El rango
-- usa >= desde y < hasta + 1 y no BETWEEN: fecha_pedido es un DATE con hora
-- (default SYSDATE) y BETWEEN con 2026-12-31 dejaria fuera los pedidos de ese
-- dia posteriores a las 00:00. LEFT JOIN + COUNT(d.linea) para que un pedido sin
-- lineas salga con 0 en vez de desaparecer. Solo CONFIRMADO: el BORRADOR y el
-- ANULADO no son ventas. Se usa FOR implicito porque la restriccion de
-- OPEN/FETCH aplica solo al 3.1.
DECLARE
    CURSOR c_pedidos (p_cliente IN NUMBER, p_desde IN DATE, p_hasta IN DATE) IS
        SELECT p.id_pedido, p.fecha_pedido, p.total, COUNT(d.linea) AS lineas
        FROM   PEDIDO p
               LEFT JOIN DETALLE_PEDIDO d ON d.id_pedido = p.id_pedido
        WHERE  p.id_cliente = p_cliente
          AND  p.estado = 'CONFIRMADO'
          AND  p.fecha_pedido >= p_desde
          AND  p.fecha_pedido <  p_hasta + 1
        GROUP  BY p.id_pedido, p.fecha_pedido, p.total
        ORDER  BY p.fecha_pedido, p.id_pedido;
    vn_pedidos NUMBER := 0;
    vn_suma    NUMBER := 0;
BEGIN
    FOR vr_pedido IN c_pedidos(501, DATE '2026-01-01', DATE '2026-12-31') LOOP
        DBMS_OUTPUT.PUT_LINE('Pedido ' || vr_pedido.id_pedido
            || ' | ' || TO_CHAR(vr_pedido.fecha_pedido, 'YYYY-MM-DD')
            || ' | total ' || TO_CHAR(vr_pedido.total, 'FM999G999G999G990')
            || ' | ' || vr_pedido.lineas || ' lineas');
        vn_pedidos := vn_pedidos + 1;
        vn_suma    := vn_suma + vr_pedido.total;
    END LOOP;

    IF vn_pedidos = 0 THEN
        DBMS_OUTPUT.PUT_LINE('El cliente no tiene pedidos confirmados en ese rango');
    ELSE
        DBMS_OUTPUT.PUT_LINE(vn_pedidos || ' pedidos, suma total '
            || TO_CHAR(vn_suma, 'FM999G999G999G990'));
    END IF;
END;
/

------------------------------------------------------------------- 3.3 (3 pts)
-- Bloque anonimo con un CURSOR FOR UPDATE que recorra los productos de una
-- categoria y ajuste su precio un porcentaje dado, usando WHERE CURRENT OF.
--   * No debe modificar productos inactivos
--   * El precio resultante no puede quedar por debajo del costo mas el margen
--     minimo de la categoria
-- Explique que bloqueo genera FOR UPDATE, cuanto dura, y por que WHERE CURRENT OF
-- es preferible a un UPDATE por clave primaria.
-------------------------------------------------------------------------------
-- JUSTIFICACION:
-- FOR UPDATE bloquea, al hacer el OPEN, TODAS las filas del resultado (no una a
-- una al hacer FETCH) con bloqueo exclusivo de fila. Otras sesiones pueden
-- leerlas, pero no modificarlas ni borrarlas: esperan. El bloqueo dura hasta el
-- COMMIT o ROLLBACK de la transaccion, no hasta el CLOSE; por eso no se hace
-- COMMIT dentro del bucle (invalida el cursor, ORA-01002). Sin NOWAIT/WAIT, una
-- sesion que encuentre las filas bloqueadas espera indefinidamente.
-- WHERE CURRENT OF es preferible a UPDATE ... WHERE id_producto = x porque
-- actualiza exactamente la fila del ultimo FETCH (por ROWID) sin volver a
-- buscarla por la clave, no puede apuntar a otra fila por un error en el WHERE,
-- y esa fila ya esta bloqueada: nadie la cambia entre la lectura y la escritura.
-- Los inactivos se filtran en el WHERE del cursor, asi ni se tocan ni se bloquean.
-- Piso = costo * (1 + margen/100), la misma formula del trigger 5.3. Si el nuevo
-- precio queda bajo el piso, se OMITE el producto y se informa: aplicar un precio
-- distinto al pedido sin avisar es peor que no tocarlo, y el trigger 5.3
-- rechazaria ese UPDATE de todos modos.
DECLARE
    vn_categoria   NUMBER := 1;     
    vn_porcentaje  NUMBER := -22;   
    vn_margen      CATEGORIA.margen_minimo%TYPE;
    vn_piso        NUMBER;
    vn_nuevo       NUMBER;
    vn_mod         NUMBER := 0;
    vn_omit        NUMBER := 0;

    CURSOR c_prod (p_cat IN NUMBER) IS
        SELECT id_producto, codigo, precio_unitario, costo_unitario
        FROM   PRODUCTO
        WHERE  id_categoria = p_cat
          AND  activo = 'S'
        FOR UPDATE OF precio_unitario;
BEGIN
    SELECT MAX(margen_minimo)
    INTO   vn_margen
    FROM   CATEGORIA
    WHERE  id_categoria = vn_categoria;

    IF vn_margen IS NULL THEN
        DBMS_OUTPUT.PUT_LINE('La categoria ' || vn_categoria || ' no existe');
        RETURN;
    END IF;

    FOR vr_prod IN c_prod(vn_categoria) LOOP
        vn_piso  := vr_prod.costo_unitario * (1 + vn_margen / 100);
        vn_nuevo := ROUND(vr_prod.precio_unitario * (1 + vn_porcentaje / 100), 2);

        IF vn_nuevo < vn_piso THEN
            DBMS_OUTPUT.PUT_LINE(vr_prod.codigo || ' omitido: ' || vn_nuevo
                || ' quedaria bajo el piso ' || vn_piso);
            vn_omit := vn_omit + 1;
        ELSE
            UPDATE PRODUCTO
            SET    precio_unitario = vn_nuevo
            WHERE CURRENT OF c_prod;
            DBMS_OUTPUT.PUT_LINE(vr_prod.codigo || ' actualizado: '
                || vr_prod.precio_unitario || ' -> ' || vn_nuevo);
            vn_mod := vn_mod + 1;
        END IF;
    END LOOP;

    DBMS_OUTPUT.PUT_LINE('Actualizados: ' || vn_mod || ' | Omitidos: ' || vn_omit);
END;
/


SELECT codigo, precio_unitario, costo_unitario, activo
FROM   PRODUCTO WHERE id_categoria = 1 ORDER BY id_producto;
ROLLBACK;
------------------------------------------------------------------- 3.4 (2 pts)
-- SP_LISTAR_MOVIMIENTOS
-- Procedimiento que reciba un identificador de producto y devuelva un
-- SYS_REFCURSOR con los movimientos de inventario de ese producto, ordenados
-- por fecha. Incluya un bloque anonimo que consuma el cursor devuelto y lo cierre.
-------------------------------------------------------------------------------
-- JUSTIFICACION:
-- SYS_REFCURSOR permite devolver el resultado de una consulta sin definir un
-- tipo: el procedimiento abre el cursor y el llamador lo recorre. El
-- procedimiento NO lo cierra (si lo cerrara, el llamador recibiria un cursor
-- inservible): el CLOSE es responsabilidad de quien lo consume. Para un producto
-- inexistente se devuelve un cursor vacio, asi el llamador no tiene que manejar
-- ORA-01001. ORDER BY fecha_mov, id_movimiento: varios movimientos comparten
-- fecha y el segundo criterio vuelve estable el orden. Se listan columnas, no
-- SELECT *. Limite: el cursor es debil (sin tipo fijo); si el llamador declara
-- mal las variables, el error aparece al ejecutar, no al compilar.
CREATE OR REPLACE PROCEDURE SP_LISTAR_MOVIMIENTOS (
    p_id_producto IN  NUMBER,
    p_cursor      OUT SYS_REFCURSOR
) IS
BEGIN
    OPEN p_cursor FOR
        SELECT id_movimiento, tipo, cantidad, fecha_mov,
               id_bodega, id_pedido, observacion
        FROM   MOVIMIENTO_INVENTARIO
        WHERE  id_producto = p_id_producto
        ORDER  BY fecha_mov, id_movimiento;
END SP_LISTAR_MOVIMIENTOS;
/
DECLARE
    v_cur      SYS_REFCURSOR;
    vn_id      MOVIMIENTO_INVENTARIO.id_movimiento%TYPE;
    vv_tipo    MOVIMIENTO_INVENTARIO.tipo%TYPE;
    vn_cant    MOVIMIENTO_INVENTARIO.cantidad%TYPE;
    vd_fecha   MOVIMIENTO_INVENTARIO.fecha_mov%TYPE;
    vn_bodega  MOVIMIENTO_INVENTARIO.id_bodega%TYPE;
    vn_pedido  MOVIMIENTO_INVENTARIO.id_pedido%TYPE;
    vv_obs     MOVIMIENTO_INVENTARIO.observacion%TYPE;
    vn_n       NUMBER;
BEGIN
    SP_LISTAR_MOVIMIENTOS(1001, v_cur);
    LOOP
        FETCH v_cur INTO vn_id, vv_tipo, vn_cant, vd_fecha, vn_bodega, vn_pedido, vv_obs;
        EXIT WHEN v_cur%NOTFOUND;
        DBMS_OUTPUT.PUT_LINE(vn_id || ' | ' || TO_CHAR(vd_fecha, 'YYYY-MM-DD')
            || ' | ' || RPAD(vv_tipo, 8) || ' | ' || LPAD(vn_cant, 5)
            || ' | bodega ' || vn_bodega
            || ' | pedido ' || NVL(TO_CHAR(vn_pedido), '-')
            || ' | ' || vv_obs);
    END LOOP;
    vn_n := v_cur%ROWCOUNT;
    CLOSE v_cur;
    DBMS_OUTPUT.PUT_LINE('Movimientos del producto 1001: ' || vn_n);

    -- Producto inexistente: el cursor llega vacio, sin error
    SP_LISTAR_MOVIMIENTOS(9999, v_cur);
    FETCH v_cur INTO vn_id, vv_tipo, vn_cant, vd_fecha, vn_bodega, vn_pedido, vv_obs;
    IF v_cur%NOTFOUND THEN
        DBMS_OUTPUT.PUT_LINE('Producto 9999: sin movimientos');
    END IF;
    CLOSE v_cur;
END;
/

------------------------------------------------------------------- 3.5 (1 pt)
-- Bloque anonimo que cargue con BULK COLLECT los productos de una categoria en
-- una coleccion y use FORALL para actualizar su stock minimo.
-- Explique que costo concreto elimina esta tecnica y a partir de que volumen
-- empieza a notarse.
-------------------------------------------------------------------------------
-- JUSTIFICACION:
-- Costo que elimina: los cambios de contexto entre el motor PL/SQL y el motor SQL.
-- Un UPDATE dentro de un LOOP envia una sentencia al motor SQL por cada fila (N
-- cambios de contexto); BULK COLLECT lee todas las filas en un solo viaje y FORALL
-- manda todo el lote en una sola llamada. Con decenas de filas no se nota (aqui
-- son 3); empieza a notarse hacia los miles de filas, y con cientos de miles la
-- diferencia es de segundos contra fracciones de segundo (depende del servidor).
-- Limite: BULK COLLECT sin LIMIT carga todo en memoria; con tablas grandes se
-- lee por lotes (FETCH ... BULK COLLECT LIMIT n). Se valida COUNT > 0 antes del
-- FORALL para no ejecutarlo sobre una coleccion vacia.
DECLARE
    TYPE t_ids IS TABLE OF PRODUCTO.id_producto%TYPE;
    v_ids         t_ids;
    vn_categoria  NUMBER := 2;
    vn_pct        NUMBER := 20; 
BEGIN
    SELECT id_producto
    BULK COLLECT INTO v_ids
    FROM   PRODUCTO
    WHERE  id_categoria = vn_categoria;

    IF v_ids.COUNT = 0 THEN
        DBMS_OUTPUT.PUT_LINE('La categoria ' || vn_categoria || ' no tiene productos');
        RETURN;
    END IF;

    FORALL i IN 1 .. v_ids.COUNT
        UPDATE PRODUCTO
        SET    stock_minimo = CEIL(stock_minimo * (1 + vn_pct / 100))
        WHERE  id_producto = v_ids(i);

    DBMS_OUTPUT.PUT_LINE('Productos leidos: ' || v_ids.COUNT
        || ' | filas actualizadas: ' || SQL%ROWCOUNT);
END;
/
SELECT id_producto, codigo, stock_minimo FROM PRODUCTO
WHERE id_categoria = 2 ORDER BY id_producto;
ROLLBACK;
--==============================================================================
-- PARTE 4 — MANEJO DE EXCEPCIONES (9 puntos / 75 min)
--==============================================================================
------------------------------------------------------------------- 4.1 (2 pts)
-- FN_PRECIO_PRODUCTO
-- Funcion que reciba el CODIGO de un producto y retorne su precio, manejando
-- explicitamente NO_DATA_FOUND y TOO_MANY_ROWS, con retorno de -1 y -2
-- respectivamente, e imprimiendo un mensaje descriptivo en cada caso.
-- Explique en que situacion real se produciria TOO_MANY_ROWS sobre esta tabla,
-- considerando las restricciones que hoy tiene.
-------------------------------------------------------------------------------
-- JUSTIFICACION:
-- Uso SELECT INTO porque es la construccion que levanta NO_DATA_FOUND cuando
-- no hay producto y TOO_MANY_ROWS cuando hay mas de uno, que son las dos
-- excepciones que pide el enunciado. Cada una la atiendo por separado, con un
-- mensaje que dice cual codigo fallo, y devuelvo -1 o -2 para que quien llame
-- la funcion pueda distinguir los casos. No use WHEN OTHERS para no esconder
-- otros errores.
-- TOO_MANY_ROWS hoy no se puede producir porque codigo tiene restriccion UNIQUE
-- y NOT NULL. Solo pasaria si se elimina o deshabilita esa restriccion y se
-- insertan codigos repetidos, o si se buscara por una columna que no es unica,
-- como el nombre. Por eso el manejador es una proteccion ante cambios futuros.
CREATE OR REPLACE FUNCTION FN_PRECIO_PRODUCTO (
    p_codigo IN VARCHAR2
) RETURN NUMBER IS
    vn_precio NUMBER;
BEGIN
    SELECT precio_unitario
    INTO   vn_precio
    FROM   PRODUCTO
    WHERE  codigo = p_codigo;

    RETURN vn_precio;
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        DBMS_OUTPUT.PUT_LINE('No existe un producto con el codigo ' || p_codigo);
        RETURN -1;
    WHEN TOO_MANY_ROWS THEN
        DBMS_OUTPUT.PUT_LINE('Hay mas de un producto con el codigo ' || p_codigo);
        RETURN -2;
END FN_PRECIO_PRODUCTO;
/


DECLARE
    vn_resultado NUMBER;
BEGIN
    vn_resultado := FN_PRECIO_PRODUCTO('HM-0001');
    DBMS_OUTPUT.PUT_LINE('Resultado: ' || vn_resultado);

    vn_resultado := FN_PRECIO_PRODUCTO('ME-0001');
    DBMS_OUTPUT.PUT_LINE('Resultado: ' || vn_resultado);

    vn_resultado := FN_PRECIO_PRODUCTO('XX-0000');
    DBMS_OUTPUT.PUT_LINE('Resultado: ' || vn_resultado);
END;
/
------------------------------------------------------------------- 4.2 (2 pts)
-- SP_VALIDAR_DESPACHO
-- Procedimiento que verifique si puede despacharse una cantidad de un producto
-- desde una bodega. Debe declarar una EXCEPCION PROPIA, levantarla con RAISE
-- cuando la cantidad solicitada supere el disponible, y capturarla en el bloque
-- EXCEPTION.
-- Argumente por que conviene nombrar esa condicion en lugar de resolverla con un
-- condicional.
-------------------------------------------------------------------------------
-- JUSTIFICACION:
-- Declaro una excepcion propia, e_stock_insuficiente, y la levanto con RAISE
-- cuando la cantidad pedida es mayor que lo que hay. El disponible lo saco con
-- FN_STOCK_DISPONIBLE para no repetir esa logica.
-- Le puse nombre a la condicion porque asi la regla de negocio queda clara y en
-- un solo lugar: el IF solo detecta el problema y el manejador decide que hacer.
-- Tambien se distingue de cualquier otro error sin usar WHEN OTHERS.
-- En el manejador muestro cuanto hay y cuanto pidieron, y despues la convierto
-- en el error -20040 con RAISE_APPLICATION_ERROR. Lo hice asi porque si solo la
-- imprimia, el procedimiento terminaba "bien" y quien lo llamara podia seguir
-- con el despacho sin tener stock.
-- La bodega nula la rechazo (-20041) porque FN_STOCK_DISPONIBLE con NULL suma
-- todas las bodegas, y un despacho sale de una bodega en concreto.
CREATE OR REPLACE PROCEDURE SP_VALIDAR_DESPACHO (
    p_id_producto IN NUMBER,
    p_id_bodega   IN NUMBER,
    p_cantidad    IN NUMBER
) IS
    e_stock_insuficiente EXCEPTION;
    vn_disponible NUMBER;
BEGIN
    IF p_id_bodega IS NULL THEN
        RAISE_APPLICATION_ERROR(-20041, 'La bodega es obligatoria para un despacho');
    END IF;
    IF p_cantidad IS NULL OR p_cantidad <= 0 THEN
        RAISE_APPLICATION_ERROR(-20041, 'La cantidad debe ser mayor que cero');
    END IF;

    vn_disponible := FN_STOCK_DISPONIBLE(p_id_producto, p_id_bodega);

    IF p_cantidad > vn_disponible THEN
        RAISE e_stock_insuficiente;
    END IF;

    DBMS_OUTPUT.PUT_LINE('Si se puede despachar. Disponible: ' || vn_disponible ||
                         ', solicitado: ' || p_cantidad);
EXCEPTION
    WHEN e_stock_insuficiente THEN
        DBMS_OUTPUT.PUT_LINE('Stock insuficiente. Disponible: ' || vn_disponible ||
                             ', solicitado: ' || p_cantidad);
        RAISE_APPLICATION_ERROR(-20040, 'Stock insuficiente. Disponible: ' ||
                                vn_disponible || ', solicitado: ' || p_cantidad);
END SP_VALIDAR_DESPACHO;
/

BEGIN
    BEGIN SP_VALIDAR_DESPACHO(1001, 1, 50);
    EXCEPTION WHEN OTHERS THEN DBMS_OUTPUT.PUT_LINE(SQLCODE || ' ' || SQLERRM); END;
    BEGIN SP_VALIDAR_DESPACHO(1001, 1, 200);
    EXCEPTION WHEN OTHERS THEN DBMS_OUTPUT.PUT_LINE(SQLCODE || ' ' || SQLERRM); END;
    BEGIN SP_VALIDAR_DESPACHO(1001, 3, 5);
    EXCEPTION WHEN OTHERS THEN DBMS_OUTPUT.PUT_LINE(SQLCODE || ' ' || SQLERRM); END;
    BEGIN SP_VALIDAR_DESPACHO(9999, 1, 1);
    EXCEPTION WHEN OTHERS THEN DBMS_OUTPUT.PUT_LINE(SQLCODE || ' ' || SQLERRM); END;
    BEGIN SP_VALIDAR_DESPACHO(1001, NULL, 1);
    EXCEPTION WHEN OTHERS THEN DBMS_OUTPUT.PUT_LINE(SQLCODE || ' ' || SQLERRM); END;
        BEGIN SP_VALIDAR_DESPACHO(1001, 1, 0);
    EXCEPTION WHEN OTHERS THEN DBMS_OUTPUT.PUT_LINE(SQLCODE || ' ' || SQLERRM); END;
END;
/
------------------------------------------------------------------- 4.3 (2 pts)
-- SP_ANULAR_PEDIDO
-- Procedimiento que anule un pedido, usando RAISE_APPLICATION_ERROR con estos
-- codigos:
-- -20010 el pedido no existe
-- -20011 el pedido ya esta anulado
-- -20012 el pedido tiene mas de 30 dias
-- Explique la diferencia entre RAISE y RAISE_APPLICATION_ERROR, y en que caso el
-- cliente de la base de datos puede distinguirlos.
-------------------------------------------------------------------------------
-- JUSTIFICACION:
-- Use RAISE_APPLICATION_ERROR porque cada regla tiene su propio codigo (-20010,
-- -20011, -20012) y asi quien llama sabe cual fallo. El SELECT va en su propio
-- bloque para convertir el NO_DATA_FOUND en mi -20010. No hice COMMIT, eso lo
-- decide quien llama.
-- Diferencia: RAISE levanta una excepcion declarada y solo se ve dentro de
-- PL/SQL; si nadie la maneja, el cliente recibe un ORA-06510 generico.
-- RAISE_APPLICATION_ERROR manda el error con numero propio (-20000 a -20999)
-- hasta el cliente, y ahi si distingue cada caso por el codigo.
-- Operacional: solo cambia el estado a ANULADO. Si el pedido estaba CONFIRMADO,
-- el saldo del cliente y el stock no se devuelven y queda debiendo por un pedido
-- que ya no existe. Tampoco bloquea el pedido: dos anulaciones al tiempo no se
-- enteran entre ellas (se arregla con FOR UPDATE).

CREATE OR REPLACE PROCEDURE SP_ANULAR_PEDIDO (
    p_id_pedido IN NUMBER
) IS
    vv_estado VARCHAR2(15);
    vd_fecha  DATE;
BEGIN
    BEGIN
        SELECT estado, fecha_pedido
        INTO   vv_estado, vd_fecha
        FROM   PEDIDO
        WHERE  id_pedido = p_id_pedido;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            RAISE_APPLICATION_ERROR(-20010,
                'El pedido ' || p_id_pedido || ' no existe.');
    END;

    IF vv_estado = 'ANULADO' THEN
        RAISE_APPLICATION_ERROR(-20011,
            'El pedido ' || p_id_pedido || ' ya se encuentra anulado.');
    END IF;

    IF SYSDATE - vd_fecha > 30 THEN
        RAISE_APPLICATION_ERROR(-20012,
            'El pedido ' || p_id_pedido || ' tiene mas de 30 dias y no se puede anular.');
    END IF;

    UPDATE PEDIDO
    SET    estado = 'ANULADO'
    WHERE  id_pedido = p_id_pedido;

    DBMS_OUTPUT.PUT_LINE('Pedido ' || p_id_pedido || ' anulado correctamente');
END SP_ANULAR_PEDIDO;
/



BEGIN
    INSERT INTO PEDIDO VALUES (101, 501, SYSDATE, 'BORRADOR', 0);

    BEGIN SP_ANULAR_PEDIDO(9999);  -- -20010
    EXCEPTION WHEN OTHERS THEN DBMS_OUTPUT.PUT_LINE(SQLCODE || ' ' || SQLERRM); END;
    BEGIN SP_ANULAR_PEDIDO(7);     -- -20011
    EXCEPTION WHEN OTHERS THEN DBMS_OUTPUT.PUT_LINE(SQLCODE || ' ' || SQLERRM); END;
    BEGIN SP_ANULAR_PEDIDO(1);     -- -20012 (pedido de junio)
    EXCEPTION WHEN OTHERS THEN DBMS_OUTPUT.PUT_LINE(SQLCODE || ' ' || SQLERRM); END;
    BEGIN SP_ANULAR_PEDIDO(101);   -- se anula bien
    EXCEPTION WHEN OTHERS THEN DBMS_OUTPUT.PUT_LINE(SQLCODE || ' ' || SQLERRM); END;
END;
/
ROLLBACK;
------------------------------------------------------------------- 4.4 (2 pts)
-- Bloque anonimo que intente insertar un producto con una categoria inexistente
-- y capture el error de integridad referencial asociando ORA-02291 a una
-- excepcion con nombre.
-- Explique que aporta esa asociacion frente a atrapar el error en un manejador
-- generico.
-------------------------------------------------------------------------------
-- JUSTIFICACION:
-- ORA-02291 es el error que sale cuando se inserta una fila que apunta a una
-- categoria que no existe (la llave foranea no encuentra a su padre). Oracle no
-- le da nombre, asi que declare e_fk_violada y se lo asocie con pragma
-- exception_init(e_fk_violada, -2291); el numero va negativo.
-- Prefiero esto a un when others porque el manejador atiende solo ese error:
-- con when others se trataria igual una categoria inexistente, un codigo
-- duplicado o una caida de conexion, y el mensaje no podria ser especifico.
-- Con el nombre, cualquier otro error no entra aqui y sigue subiendo, asi no se
-- esconde. Ademas el codigo se lee solo: when e_fk_violada dice que paso sin
-- tener que mirar el sqlcode.
-- Uso el id 9999 fijo y no la secuencia porque seq_producto esta desfasada
-- respecto a los productos cargados; con la secuencia podia chocar primero la
-- llave primaria (ORA-00001) y nunca se probaria la categoria.
-- Operacion: el insert que falla se deshace completo, no queda nada a medias ni
-- hace falta rollback. Este bloque solo imprime el error y termina normal; en un
-- proceso real convendria registrarlo con sp_registrar_error y volver a
-- lanzarlo para que quien llame se entere.
DECLARE
    e_fk_violada EXCEPTION;
    PRAGMA EXCEPTION_INIT(e_fk_violada, -2291);
BEGIN
    INSERT INTO PRODUCTO (id_producto, codigo, nombre, id_categoria,
                          precio_unitario, costo_unitario, stock_minimo, activo)
    VALUES (9999, 'XX-9999', 'Producto de prueba', 99,
            50000, 30000, 10, 'S');

    DBMS_OUTPUT.PUT_LINE('Producto insertado');
EXCEPTION
    WHEN e_fk_violada THEN
        DBMS_OUTPUT.PUT_LINE('Integridad referencial: la categoria ' || 99 || ' no existe.');
        DBMS_OUTPUT.PUT_LINE('Codigo del error: ' || SQLCODE);
        DBMS_OUTPUT.PUT_LINE('Detalle Oracle: ' || SQLERRM);
END;
/
----------------------------------------------------------------- 4.5 (1 pt)
-- SP_REGISTRAR_ERROR
-- Procedimiento que reciba el origen y registre en LOG_ERRORES el SQLCODE y el
-- SQLERRM actuales. El registro debe persistir aunque la transaccion principal
-- termine en ROLLBACK.
-- Explique por que se requiere esa independencia transaccional y describa un
-- escenario en el que esa misma independencia oculte informacion en lugar de
-- preservarla.
-------------------------------------------------------------------------------
-- JUSTIFICACION:
-- Uso pragma autonomous_transaction para que el registro corra en su propia
-- transaccion y no dependa de la que fallo. Primero guardo el codigo, el
-- mensaje y la traza del error en variables, y recorto cada texto al tamano de
-- su columna. Si no me dicen el origen pongo un texto por defecto, porque esa
-- columna no acepta nulos. Hago commit dentro del procedimiento porque en una
-- transaccion autonoma es obligatorio.
-- Se necesita la independencia porque, sin ella, el rollback que deshace el
-- fallo tambien borraria el registro del error y se perderia la evidencia.
-- Esa misma independencia puede ocultar informacion si el registro queda
-- guardado aunque la operacion se revirtio: el log mencionaria un pedido que ya
-- no existe, o un error de un proceso que despues se reintento y salio bien, y
-- daria una imagen incompleta de lo que paso.
CREATE OR REPLACE PROCEDURE SP_REGISTRAR_ERROR (
    p_origen  IN VARCHAR2,
    p_detalle IN VARCHAR2 DEFAULT NULL
) IS
    PRAGMA AUTONOMOUS_TRANSACTION;
    vn_codigo  NUMBER;
    vv_mensaje VARCHAR2(500);
    vv_traza   VARCHAR2(500);
    vv_origen  VARCHAR2(60);
    vv_detalle VARCHAR2(500);
BEGIN
    vn_codigo  := SQLCODE;
    vv_mensaje := SUBSTR(SQLERRM, 1, 500);
    vv_traza   := SUBSTR(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE, 1, 500);

    IF p_origen IS NULL THEN
        vv_origen := 'SIN_ORIGEN';
    ELSE
        vv_origen := SUBSTR(p_origen, 1, 60);
    END IF;

    vv_detalle := SUBSTR(NVL(p_detalle, 'Sin detalle') || ' | ' || vv_traza, 1, 500);

    INSERT INTO LOG_ERRORES (id_log, origen, codigo_error, mensaje, detalle)
    VALUES (SEQ_LOG.NEXTVAL, vv_origen, vn_codigo, vv_mensaje, vv_detalle);

    COMMIT;
END SP_REGISTRAR_ERROR;
/


DECLARE
    vn_x NUMBER;
BEGIN
    UPDATE PRODUCTO SET precio_unitario = precio_unitario + 1 WHERE id_producto = 1001;
    vn_x := 1 / 0;
EXCEPTION
    WHEN OTHERS THEN
        SP_REGISTRAR_ERROR('PRUEBA_4_5', 'Division por cero de prueba');
        ROLLBACK;
END;
/

SELECT precio_unitario FROM PRODUCTO WHERE id_producto = 1001;

SELECT id_log, origen, codigo_error, mensaje, detalle FROM LOG_ERRORES;

--==============================================================================
-- PARTE 5 — DISPARADORES                                     (10 puntos / 90 min)
--==============================================================================
-- Los esqueletos de esta parte no incluyen la clausula de disparo. Definirla
-- hace parte del ejercicio.
--==============================================================================

------------------------------------------------------------------- 5.1 (2 pts)
-- TRG_CLIENTE_BI
-- Al insertar un cliente debe asignar el identificador desde SEQ_CLIENTE si
-- llega nulo, convertir el nombre a mayusculas sin espacios sobrantes y forzar
-- el estado activo a 'S' si no se indica.
-------------------------------------------------------------------------------
-- JUSTIFICACION:
-- BEFORE INSERT porque el trigger modifica :NEW, y eso solo es posible antes de
-- que la fila se escriba; FOR EACH ROW porque trabaja con los valores de cada
-- fila. El id se toma de la secuencia SOLO si llega nulo, para respetar un id
-- indicado a proposito. El nombre se normaliza con TRIM, colapsando espacios
-- repetidos internos (REGEXP_REPLACE) y UPPER. Para el estado: si la columna se
-- omite, el DEFAULT 'S' de la tabla ya la llena antes del trigger; lo que el
-- DEFAULT no cubre es un NULL explicito, que violaria el NOT NULL, y eso lo
-- resuelve el NVL. Limites: la secuencia debe estar sincronizada con los
-- clientes existentes, el numero consumido no se devuelve si el INSERT falla, y
-- el trigger actua solo en INSERT (un UPDATE del nombre no se normaliza).
CREATE OR REPLACE TRIGGER TRG_CLIENTE_BI
BEFORE INSERT ON CLIENTE 
FOR EACH ROW
BEGIN 
    IF :NEW.id_cliente IS NULL THEN
       :NEW.id_cliente := SEQ_CLIENTE.NEXTVAL;
    END IF;
    :NEW.nombre := UPPER(REGEXP_REPLACE(TRIM(:NEW.nombre), '\s+', ' '));
    IF :NEW.activo IS NULL THEN
        :NEW.activo := 'S';
    END IF;
END TRG_CLIENTE_BI;
/

-- PRUEBA 
-- LE PUSIMOS ROLLBACK AL FINAL PARA NO AFECTAR LAS DEMAS PRUEBAS
ALTER SEQUENCE SEQ_CLIENTE RESTART START WITH 508;

INSERT INTO CLIENTE (id_cliente, documento, nombre, ciudad, cupo_credito, saldo_pendiente, activo)
VALUES (NULL, '900999001', '  ferreteria    el  tornillo ', 'Bogota', 1000000, 0, NULL);
INSERT INTO CLIENTE (documento, nombre, ciudad) VALUES ('900999002', 'distribuidora  sur', 'Cali');
INSERT INTO CLIENTE (id_cliente, documento, nombre, ciudad) VALUES (600, '900999003', 'Cliente con id propio', 'Cali');
SELECT id_cliente, nombre, activo FROM CLIENTE WHERE documento LIKE '9009990%' ORDER BY id_cliente;
ROLLBACK;
------------------------------------------------------------------- 5.2 (2 pts)
-- TRG_PRODUCTO_AU_PRECIO
-- Debe registrar en AUDITORIA_PRECIO todo cambio de precio, calculando la
-- variacion porcentual, y dispararse unicamente cuando el precio efectivamente
-- cambie, resolviendo esa condicion con la clausula WHEN y no dentro del cuerpo.
-- Explique la diferencia entre ambas formas.
-------------------------------------------------------------------------------
-- JUSTIFICACION:
-- La condicion "el precio cambio" va en WHEN y no dentro del cuerpo. Con WHEN,
-- Oracle evalua la condicion antes de ejecutar el trigger: si es falsa, el bloque
-- PL/SQL ni se arranca. Con un IF en el cuerpo el trigger se dispara y se ejecuta
-- por cada fila actualizada y solo despues decide no hacer nada; en un UPDATE
-- masivo ese costo se multiplica por el numero de filas. WHEN solo existe en
-- triggers de fila y usa NEW/OLD sin dos puntos. UPDATE OF precio_unitario es un
-- primer filtro por columna, pero se activa aunque el valor sea el mismo; WHEN
-- afina a un cambio real (SET precio = precio no audita). AFTER porque la
-- auditoria se registra una vez el UPDATE de la fila ya se aplico, y va en la
-- misma transaccion: si se hace ROLLBACK, la auditoria tambien se deshace. La
-- division por :OLD no falla porque ck_producto_precio garantiza precio > 0.
CREATE OR REPLACE TRIGGER TRG_PRODUCTO_AU_PRECIO
AFTER UPDATE OF precio_unitario ON PRODUCTO
FOR EACH ROW
WHEN (NEW.precio_unitario <> OLD.precio_unitario)
BEGIN
    INSERT INTO AUDITORIA_PRECIO (id_auditoria, id_producto, precio_anterior,
                                  precio_nuevo, variacion_pct)
    VALUES (SEQ_AUDITORIA.NEXTVAL, :OLD.id_producto, :OLD.precio_unitario,
            :NEW.precio_unitario,
            ROUND((:NEW.precio_unitario - :OLD.precio_unitario)
                  / :OLD.precio_unitario * 100, 2));
END TRG_PRODUCTO_AU_PRECIO;
/
-- PRUEBA 
-- LE PUSIMOS ROLLBACK AL FINAL PARA NO AFECTAR LAS DEMAS PRUEBAS
UPDATE PRODUCTO SET precio_unitario = 47000 WHERE id_producto = 1001;                 
UPDATE PRODUCTO SET precio_unitario = precio_unitario WHERE id_producto = 1002;       
UPDATE PRODUCTO SET nombre = 'Martillo carpintero 16 oz' WHERE id_producto = 1001;    
SELECT id_producto, precio_anterior, precio_nuevo, variacion_pct FROM AUDITORIA_PRECIO;
ROLLBACK;

------------------------------------------------------------------- 5.3 (2 pts)
-- TRG_PRODUCTO_BIU_MARGEN
-- Debe impedir que se guarde un producto cuyo precio no alcance el margen minimo
-- de su categoria, segun la formula precio >= costo * (1 + margen/100),
-- rechazando la operacion con el error -20020.
-- Considere que debe ocurrir cuando la categoria indicada no existe, y justifique
-- su decision.
-------------------------------------------------------------------------------
-- JUSTIFICACION:
-- BEFORE para rechazar antes de escribir la fila, y FOR EACH ROW porque compara
-- el precio y el costo de cada una. Rechazar exige una excepcion: un mensaje no
-- detiene el DML. UPDATE OF precio_unitario, costo_unitario, id_categoria: solo se
-- revalida cuando cambia algo que afecta el margen, asi actualizar el nombre no
-- consulta CATEGORIA ni se bloquea por un precio historico. CATEGORIA es otra
-- tabla, por eso no hay problema de tabla mutante.
-- Categoria inexistente: el trigger NO rechaza y deja pasar la fila; la FK
-- fk_producto_categoria la rechaza con ORA-02291. Razones: (1) la existencia de la
-- categoria es responsabilidad de la FK, no de este trigger; (2) -20020 significa
-- "margen insuficiente", usarlo para otra cosa seria engañoso; (3) el punto 4.4
-- necesita ver ORA-02291 al insertar con categoria inexistente, y un trigger que
-- lanzara -20020 antes lo haria inalcanzable. MAX(margen_minimo) devuelve NULL si
-- no hay categoria, sin NO_DATA_FOUND. Limite: si despues cambia el margen de
-- una categoria, los productos ya guardados no se revalidan.
CREATE OR REPLACE TRIGGER TRG_PRODUCTO_BIU_MARGEN
BEFORE INSERT OR UPDATE OF precio_unitario, costo_unitario, id_categoria
ON PRODUCTO
FOR EACH ROW
DECLARE
    v_margen  CATEGORIA.margen_minimo%TYPE;
    v_piso    NUMBER;
BEGIN
    SELECT MAX(margen_minimo)
    INTO   v_margen
    FROM   CATEGORIA
    WHERE  id_categoria = :NEW.id_categoria;

    IF v_margen IS NOT NULL THEN
        v_piso := :NEW.costo_unitario * (1 + v_margen / 100);
        IF :NEW.precio_unitario < v_piso THEN
            RAISE_APPLICATION_ERROR(-20020,
                'Precio ' || :NEW.precio_unitario || ' por debajo del minimo '
                || v_piso || ' (costo ' || :NEW.costo_unitario
                || ' + margen ' || v_margen || '%)');
        END IF;
    END IF;
END TRG_PRODUCTO_BIU_MARGEN;
/
-- PRUEBA 
-- LE PUSIMOS ROLLBACK AL FINAL PARA NO AFECTAR LAS DEMAS PRUEBAS
INSERT INTO PRODUCTO VALUES (2000, 'TST-5301', 'Prueba bajo margen', 1, 30000, 28000, 5, 'S'); 
INSERT INTO PRODUCTO VALUES (2000, 'TST-5301', 'Prueba con margen', 1, 36000, 28000, 5, 'S');  
UPDATE PRODUCTO SET precio_unitario = 30000 WHERE id_producto = 1001;                         
UPDATE PRODUCTO SET nombre = 'Martillo 16oz' WHERE id_producto = 1001;                         
INSERT INTO PRODUCTO VALUES (2001, 'TST-5302', 'Categoria falsa', 99, 36000, 28000, 5, 'S');
ROLLBACK;

------------------------------------------------------------------- 5.4 (2 pts)
-- TRG_DETALLE_AI_STOCK
-- Al insertar una linea de pedido debe descontar el stock de la bodega indicada
-- y registrar el movimiento de SALIDA correspondiente. Si no hay stock suficiente
-- debe abortar la operacion con el error -20030.
-- Explique por que el momento de disparo que eligio es el correcto y que dejaria
-- de funcionar con el contrario.
-------------------------------------------------------------------------------
-- JUSTIFICACION:
-- AFTER INSERT FOR EACH ROW: el efecto sobre otras tablas (existencia y
-- movimiento) debe ocurrir cuando la linea ya fue aceptada, es decir, despues de
-- pasar sus FK y CHECK; ademas el trigger no necesita modificar :NEW, que es lo
-- unico que exigiria un BEFORE. Con BEFORE el stock no se corrompe (Oracle revierte
-- la sentencia completa si algo falla), pero el trigger actuaria sobre una linea
-- que aun no valido sus FK: con un producto inexistente se obtendria -20030
-- "sin stock" en lugar del error real de integridad, y se haria trabajo y
-- bloqueos para nada.
-- El descuento es un solo UPDATE con la condicion cantidad >= solicitada: no hay
-- SELECT previo, asi que dos sesiones no pueden leer el mismo saldo; la segunda
-- espera el bloqueo de la fila y reevalua la condicion. Si no actualiza ninguna
-- fila (saldo insuficiente o combinacion inexistente) se aborta con -20030 y
-- Oracle revierte la linea insertada. No se reutiliza SP_AJUSTAR_STOCK porque
-- avisa con mensajes y no con excepcion, y no registra id_pedido en el
-- movimiento. Limite: solo contempla INSERT; modificar o borrar una linea no
-- devuelve ni descuenta stock.
CREATE OR REPLACE TRIGGER TRG_DETALLE_AI_STOCK
AFTER INSERT ON DETALLE_PEDIDO
FOR EACH ROW
BEGIN
    UPDATE EXISTENCIA
    SET    cantidad = cantidad - :NEW.cantidad
    WHERE  id_bodega   = :NEW.id_bodega
      AND  id_producto = :NEW.id_producto
      AND  cantidad   >= :NEW.cantidad;

    IF SQL%ROWCOUNT = 0 THEN
        RAISE_APPLICATION_ERROR(-20030,
            'Stock insuficiente del producto ' || :NEW.id_producto
            || ' en la bodega ' || :NEW.id_bodega
            || ' (solicitado ' || :NEW.cantidad || ')');
    END IF;

    INSERT INTO MOVIMIENTO_INVENTARIO (id_movimiento, id_producto, id_bodega,
                                       tipo, cantidad, id_pedido, observacion)
    VALUES (SEQ_MOVIMIENTO.NEXTVAL, :NEW.id_producto, :NEW.id_bodega,
            'SALIDA', :NEW.cantidad, :NEW.id_pedido,
            'Linea ' || :NEW.linea || ' del pedido');
END TRG_DETALLE_AI_STOCK;
/
------------------------------------------------------------------- 5.5 (1 pt)
-- TRG_DETALLE_TOTAL
-- Debe recalcular el total de la cabecera del pedido despues de cualquier
-- insercion, actualizacion o borrado de sus lineas.
-- Documente el error que obtiene en su primer intento, en que momento aparece,
-- y como lo resuelve la construccion que finalmente utilizo.
-- Este punto no se califica sin esa explicacion.
-------------------------------------------------------------------------------
-- JUSTIFICACION:
-- Primer intento: un trigger de fila (AFTER INSERT OR UPDATE OR DELETE ... FOR
-- EACH ROW) que hacia UPDATE PEDIDO SET total = (SELECT NVL(SUM(subtotal), 0)
-- FROM DETALLE_PEDIDO WHERE id_pedido = NVL(:NEW.id_pedido, :OLD.id_pedido)).
-- Error obtenido: ORA-04091 (table DETALLE_PEDIDO is mutating, trigger/function
-- may not see it), con ORA-06512 en la linea 2 del trigger (el SELECT SUM) y
-- ORA-04088. Aparece en EJECUCION y no al compilar: el trigger se creo sin
-- problema ("Trigger compiled") y fallo en el primer INSERT y tambien en el
-- primer UPDATE sobre DETALLE_PEDIDO.
-- Causa: un trigger de fila se ejecuta EN MEDIO de la sentencia que esta
-- modificando DETALLE_PEDIDO. En ese instante la tabla esta a medias (unas
-- filas ya cambiadas y otras no), asi que el SUM leeria un estado incoherente
-- que dependeria del orden en que Oracle procese las filas. Oracle lo impide
-- con ORA-04091: el error es la proteccion, no la causa del problema.

CREATE OR REPLACE TRIGGER TRG_DETALLE_TOTAL
AFTER INSERT OR UPDATE OR DELETE ON DETALLE_PEDIDO
FOR EACH ROW
BEGIN
    UPDATE PEDIDO
    SET    total = (SELECT NVL(SUM(subtotal), 0) FROM DETALLE_PEDIDO
                    WHERE id_pedido = NVL(:NEW.id_pedido, :OLD.id_pedido))
    WHERE  id_pedido = NVL(:NEW.id_pedido, :OLD.id_pedido);
END;
/

INSERT INTO DETALLE_PEDIDO VALUES (6, 1, 1001, 1, 2, 45000, 90000);   
UPDATE DETALLE_PEDIDO SET cantidad = 3 WHERE id_pedido = 1 AND linea = 1;
ROLLBACK;

CREATE OR REPLACE TRIGGER TRG_DETALLE_TOTAL
FOR INSERT OR UPDATE OR DELETE ON DETALLE_PEDIDO
COMPOUND TRIGGER

    TYPE t_pedidos IS TABLE OF NUMBER INDEX BY PLS_INTEGER;
    g_pedidos  t_pedidos;

    AFTER EACH ROW IS
    BEGIN
        IF INSERTING OR UPDATING THEN
            g_pedidos(:NEW.id_pedido) := :NEW.id_pedido;
        END IF;
        IF DELETING OR UPDATING THEN
            g_pedidos(:OLD.id_pedido) := :OLD.id_pedido;
        END IF;
    END AFTER EACH ROW;

    AFTER STATEMENT IS
        v_id  PLS_INTEGER;
    BEGIN
        v_id := g_pedidos.FIRST;
        WHILE v_id IS NOT NULL LOOP
            UPDATE PEDIDO
            SET    total = (SELECT NVL(SUM(subtotal), 0)
                            FROM   DETALLE_PEDIDO
                            WHERE  id_pedido = v_id)
            WHERE  id_pedido = v_id;
            v_id := g_pedidos.NEXT(v_id);
        END LOOP;
        g_pedidos.DELETE;
    END AFTER STATEMENT;

END TRG_DETALLE_TOTAL;
/
-- PRUEBA 5.4 Y 5.5
-- LE PUSIMOS ROLLBACK AL FINAL PARA NO AFECTAR LAS DEMAS PRUEBAS

-- 1. Linea valida: total 90000, existencia 118, movimiento SALIDA con id_pedido 6
INSERT INTO DETALLE_PEDIDO VALUES (6, 1, 1001, 1, 2, 45000, 90000);
SELECT total FROM PEDIDO WHERE id_pedido = 6;
SELECT cantidad FROM EXISTENCIA WHERE id_bodega = 1 AND id_producto = 1001;
SELECT id_movimiento, id_producto, id_bodega, tipo, cantidad, id_pedido
FROM MOVIMIENTO_INVENTARIO WHERE id_movimiento > 20;

-- 2. Sin stock (1005 en bodega 1 solo tiene 4): ORA-20030 y el total NO cambia
INSERT INTO DETALLE_PEDIDO VALUES (6, 2, 1005, 1, 50, 285000, 14250000);
SELECT total FROM PEDIDO WHERE id_pedido = 6;     -- sigue en 90000

-- 3. Dos lineas en una sola sentencia: el total se recalcula una vez
INSERT INTO DETALLE_PEDIDO
SELECT 6, 3, 1002, 1, 1, 62000, 62000 FROM DUAL
UNION ALL
SELECT 6, 4, 1003, 1, 1, 38000, 38000 FROM DUAL;
SELECT total FROM PEDIDO WHERE id_pedido = 6;     -- 190000

-- 4. UPDATE y DELETE de lineas
UPDATE DETALLE_PEDIDO SET cantidad = 3, subtotal = 135000 WHERE id_pedido = 6 AND linea = 1;
SELECT total FROM PEDIDO WHERE id_pedido = 6;     -- 235000
DELETE FROM DETALLE_PEDIDO WHERE id_pedido = 6;
SELECT total FROM PEDIDO WHERE id_pedido = 6;     -- 0
ROLLBACK;

------------------------------------------------------------------- 5.6 (1 pt)
-- TRG_V_STOCK_IO
-- Debe permitir actualizar el precio y el stock minimo del producto a traves de
-- la vista V_STOCK_CONSOLIDADO.
-- Explique por que esa vista no es actualizable de forma directa.
-------------------------------------------------------------------------------
-- JUSTIFICACION:
-- La vista no es actualizable porque tiene GROUP BY y SUM: cada fila resume
-- varias de EXISTENCIA y sus columnas (stock_total, categoria) no corresponden a
-- una celda unica de una tabla base, asi que Oracle no sabe como propagar el
-- cambio (ORA-01732). Un INSTEAD OF reemplaza el UPDATE por logica propia: aqui
-- propaga precio y stock minimo a PRODUCTO, que si se identifica de forma unica
-- por id_producto, expuesto por la vista. Los INSTEAD OF son siempre de fila. Si el
-- UPDATE intenta cambiar otra columna (stock_total, codigo, producto, categoria)
-- se rechaza con -20040 en lugar de ignorarla en silencio: quien actualiza creeria
-- que funciono. Como el cambio se hace sobre PRODUCTO, se disparan tambien 5.3 y
-- 5.2: por la vista no se puede saltar el margen minimo ni la auditoria. El
-- stock real solo se modifica con SP_AJUSTAR_STOCK.
CREATE OR REPLACE TRIGGER TRG_V_STOCK_IO
INSTEAD OF UPDATE ON V_STOCK_CONSOLIDADO
FOR EACH ROW
BEGIN
    IF :NEW.id_producto <> :OLD.id_producto
       OR :NEW.codigo     <> :OLD.codigo
       OR :NEW.producto   <> :OLD.producto
       OR :NEW.categoria  <> :OLD.categoria
       OR :NEW.stock_total <> :OLD.stock_total THEN
        RAISE_APPLICATION_ERROR(-20040,
            'Desde la vista solo se pueden actualizar precio_unitario y stock_minimo');
    END IF;

    UPDATE PRODUCTO
    SET    precio_unitario = :NEW.precio_unitario,
           stock_minimo    = :NEW.stock_minimo
    WHERE  id_producto = :OLD.id_producto;
END TRG_V_STOCK_IO;
/
-- PRUEBA 
-- LE PUSIMOS ROLLBACK AL FINAL PARA NO AFECTAR LAS DEMAS PRUEBAS
UPDATE V_STOCK_CONSOLIDADO SET precio_unitario = 47000, stock_minimo = 22 WHERE id_producto = 1001;
SELECT id_producto, precio_unitario, stock_minimo FROM PRODUCTO WHERE id_producto = 1001;   
SELECT id_producto, precio_anterior, precio_nuevo FROM AUDITORIA_PRECIO;                    
UPDATE V_STOCK_CONSOLIDADO SET stock_total = 999 WHERE id_producto = 1001;                 
UPDATE V_STOCK_CONSOLIDADO SET precio_unitario = 30000 WHERE id_producto = 1001;  
ROLLBACK;


--==============================================================================
-- PARTE 6 — CASO INTEGRADOR (5 puntos / 45 min)
--==============================================================================
-------------------------------------------------------------------------------
-- PKG_VENTAS
-- Construya un PAQUETE que exponga el procedimiento SP_FACTURAR_PEDIDO, el cual,
-- para un pedido en estado BORRADOR, debe:
--
-- 1. Validar que el pedido exista y este en BORRADOR
-- 2. Recorrer sus lineas con un cursor y acumular el subtotal
-- 3. Calcular el descuento con FN_CALCULAR_DESCUENTO
-- 4. Validar contra FN_CUPO_DISPONIBLE que el cliente tenga cupo suficiente
-- 5. Actualizar el total del pedido y cambiar su estado a CONFIRMADO
-- 6. Incrementar el saldo pendiente del cliente
-- 7. Usar SAVEPOINT y revertir parcialmente ante cualquier fallo, registrando
-- el error con SP_REGISTRAR_ERROR
-- 8. Devolver por parametros OUT el total facturado y el descuento aplicado
--
-- Firma esperada:
-- PKG_VENTAS.SP_FACTURAR_PEDIDO(p_id_pedido IN NUMBER,
-- p_total OUT NUMBER,
-- p_descuento OUT NUMBER)
--
-- Se evalua la integracion. El procedimiento debe apoyarse en los objetos de las
-- partes 1 a 5 y no reimplementar su logica: uno que vuelva a codificar el
-- calculo del descuento pierde la mitad del puntaje de esta parte.
-- Defina explicitamente el alcance transaccional y justifique donde decidio
-- ubicar la confirmacion de la transaccion.
-------------------------------------------------------------------------------
-- JUSTIFICACION:
-- Concurrencia: el pedido se lee con FOR UPDATE; si dos sesiones facturan el
-- mismo pedido, la segunda espera, y al liberarse ve estado CONFIRMADO y lo
-- rechaza (sin el bloqueo, ambas ven BORRADOR y el saldo sube dos veces).
-- El cliente tambien se bloquea ANTES de calcular descuento y cupo, porque ambos
-- dependen de saldo_pendiente; asi dos pedidos del mismo cliente no pasan del
-- cupo leyendo el mismo saldo. Siempre se bloquea en el mismo orden (pedido y
-- luego cliente) para evitar deadlocks. El ROLLBACK TO SAVEPOINT no libera los
-- bloqueos: duran hasta el COMMIT/ROLLBACK del llamador.
CREATE OR REPLACE PACKAGE PKG_VENTAS IS
    PROCEDURE SP_FACTURAR_PEDIDO (
        p_id_pedido IN  NUMBER,
        p_total     OUT NUMBER,
        p_descuento OUT NUMBER
    );
END PKG_VENTAS;
/

CREATE OR REPLACE PACKAGE BODY PKG_VENTAS IS

    PROCEDURE SP_FACTURAR_PEDIDO (
        p_id_pedido IN  NUMBER,
        p_total     OUT NUMBER,
        p_descuento OUT NUMBER
    ) IS
        vn_id_cliente NUMBER;
        vv_estado     VARCHAR2(15);
        vn_subtotal   NUMBER := 0;
        vn_lineas     NUMBER := 0;
        vn_descuento  NUMBER := 0;
        vn_total      NUMBER := 0;
        vn_cupo       NUMBER := 0;
        vn_bloqueo    NUMBER;

        CURSOR c_lineas IS
            SELECT subtotal
            FROM   DETALLE_PEDIDO
            WHERE  id_pedido = p_id_pedido;
    BEGIN
        p_total     := NULL;
        p_descuento := NULL;

        SAVEPOINT sp_facturar;

        BEGIN
            SELECT id_cliente, estado
            INTO   vn_id_cliente, vv_estado
            FROM   PEDIDO
            WHERE  id_pedido = p_id_pedido
            FOR UPDATE;
        EXCEPTION
            WHEN NO_DATA_FOUND THEN
                RAISE_APPLICATION_ERROR(-20050,
                    'El pedido ' || p_id_pedido || ' no existe.');
        END;

        IF vv_estado <> 'BORRADOR' THEN
            RAISE_APPLICATION_ERROR(-20051,
                'El pedido ' || p_id_pedido || ' esta en estado ' || vv_estado ||
                ' y solo se puede facturar un BORRADOR.');
        END IF;

        SELECT saldo_pendiente
        INTO   vn_bloqueo
        FROM   CLIENTE
        WHERE  id_cliente = vn_id_cliente
        FOR UPDATE;

        FOR reg IN c_lineas LOOP
            vn_subtotal := vn_subtotal + reg.subtotal;
            vn_lineas   := vn_lineas + 1;
        END LOOP;

        IF vn_lineas = 0 THEN
            RAISE_APPLICATION_ERROR(-20052,
                'El pedido ' || p_id_pedido || ' no tiene lineas.');
        END IF;

        vn_descuento := FN_CALCULAR_DESCUENTO(vn_id_cliente, vn_subtotal);
        vn_total     := vn_subtotal - vn_descuento;
        vn_cupo      := FN_CUPO_DISPONIBLE(vn_id_cliente);

        IF vn_total > vn_cupo THEN
            RAISE_APPLICATION_ERROR(-20053,
                'Cupo insuficiente: total ' || vn_total ||
                ', cupo disponible ' || vn_cupo);
        END IF;

        UPDATE PEDIDO
        SET    total  = vn_total,
               estado = 'CONFIRMADO'
        WHERE  id_pedido = p_id_pedido;

        UPDATE CLIENTE
        SET    saldo_pendiente = saldo_pendiente + vn_total
        WHERE  id_cliente = vn_id_cliente;

        p_total     := vn_total;
        p_descuento := vn_descuento;

        DBMS_OUTPUT.PUT_LINE('Pedido ' || p_id_pedido || ' facturado. Total: ' ||
                             vn_total || ', descuento: ' || vn_descuento);
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK TO sp_facturar;
            SP_REGISTRAR_ERROR('PKG_VENTAS.SP_FACTURAR_PEDIDO',
                               'Pedido ' || p_id_pedido);
            RAISE;
    END SP_FACTURAR_PEDIDO;

END PKG_VENTAS;
/

DECLARE
    vn_total     NUMBER;
    vn_descuento NUMBER;
    vn_saldo     NUMBER;
BEGIN
    BEGIN
        PKG_VENTAS.SP_FACTURAR_PEDIDO(p_id_pedido => 9999,
            p_total => vn_total, p_descuento => vn_descuento);
    EXCEPTION WHEN OTHERS THEN DBMS_OUTPUT.PUT_LINE(SQLERRM); END;

    BEGIN
        PKG_VENTAS.SP_FACTURAR_PEDIDO(p_id_pedido => 7,
            p_total => vn_total, p_descuento => vn_descuento);
    EXCEPTION WHEN OTHERS THEN DBMS_OUTPUT.PUT_LINE(SQLERRM); END;

    BEGIN
        PKG_VENTAS.SP_FACTURAR_PEDIDO(p_id_pedido => 6,
            p_total => vn_total, p_descuento => vn_descuento);
    EXCEPTION WHEN OTHERS THEN DBMS_OUTPUT.PUT_LINE(SQLERRM); END;

    INSERT INTO DETALLE_PEDIDO VALUES (6, 1, 1004, 1, 3, 320000, 960000);
    INSERT INTO DETALLE_PEDIDO VALUES (6, 2, 1001, 1, 10, 45000, 450000);

    PKG_VENTAS.SP_FACTURAR_PEDIDO(p_id_pedido => 6,
        p_total => vn_total, p_descuento => vn_descuento);
    DBMS_OUTPUT.PUT_LINE('OUT -> total: ' || vn_total || ', descuento: ' || vn_descuento);

    SELECT saldo_pendiente INTO vn_saldo FROM CLIENTE WHERE id_cliente = 501;
    DBMS_OUTPUT.PUT_LINE('Saldo del cliente 501: ' || vn_saldo);

    BEGIN
        PKG_VENTAS.SP_FACTURAR_PEDIDO(p_id_pedido => 6,
            p_total => vn_total, p_descuento => vn_descuento);
    EXCEPTION WHEN OTHERS THEN DBMS_OUTPUT.PUT_LINE(SQLERRM); END;

    INSERT INTO PEDIDO VALUES (100, 502, SYSDATE, 'BORRADOR', 0);
    INSERT INTO DETALLE_PEDIDO VALUES (100, 1, 1001, 1, 10, 45000, 450000);

    BEGIN
        PKG_VENTAS.SP_FACTURAR_PEDIDO(p_id_pedido => 100,
            p_total => vn_total, p_descuento => vn_descuento);
    EXCEPTION WHEN OTHERS THEN DBMS_OUTPUT.PUT_LINE(SQLERRM); END;

    ROLLBACK;
END;
/

SELECT estado, total FROM PEDIDO WHERE id_pedido = 6;
SELECT saldo_pendiente FROM CLIENTE WHERE id_cliente = 501;
SELECT origen, codigo_error, mensaje FROM LOG_ERRORES ORDER BY id_log;


--==============================================================================
-- FIN DE LA PLANTILLA
--==============================================================================